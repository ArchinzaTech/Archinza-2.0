import React, { Component } from 'react';
import  "./index.css";
import "./App.css";
import Accordian from "./Accordian1";
import './Accordian.css';
import  './Api';
import './Myaccordian'


class abc extends Component {
  render() {
    return (
        <div className='accord'>
        
            <Accordian />
        </div>
    )
  }
}



export default abc 