// General SVGs
export { default as plusicon } from "./general/plus-icon.svg";
export { default as whitelogo } from "./general/white-logo.svg";
export { default as prologo } from "./general/archinza-pro-logo.svg";
export { default as prologoblack } from "./general/archinza-pro-logo-black.svg";
export { default as blacklogo } from "./general/archinza-logo-black.svg";
export { default as fbHeader } from "./general/fb-icon.svg";
export { default as fbHeaderB } from "./general/fb-black.svg";
export { default as instaHeader } from "./general/insta-icon.svg";
export { default as instaHeaderB } from "./general/insta-black.svg";
export { default as linkedinHeader } from "./general/linkedin-icon.svg";
export { default as linkedinHeaderB } from "./general/linkedin-black.svg";
export { default as blackright } from "./general/black-right-arrow.svg";
export { default as loginicon } from "./general/login-icon.svg";
export { default as dropdownarrow } from "./general/dropdown-arrow.svg";
export { default as rightarrowwhite } from "./general/right-arrow-white.svg";
export { default as rightarrowblack } from "./general/right-arrow-black.svg";
export { default as deleteicon } from "./general/delete-icon.svg";
export { default as blackDeleteicon } from "./general/black-delete-icon.svg";
export { default as websiteicon } from "./general/website-icon.svg";
export { default as formfb } from "./general/formfb-icon.svg";
export { default as forminsta } from "./general/forminsta-icon.svg";
export { default as formupload } from "./general/cloud_upload.svg";
export { default as formLinkedin } from "./general/formLinkedin.svg";
export { default as formBehance } from "./general/formBehance.svg";
export { default as instaWhite } from "./general/forminsta-white.svg";
export { default as checkicon } from "./general/check-icon.svg";
export { default as checkiconWhite } from "./general/check-icon-white.svg";
export { default as otpicon } from "./general/otp-icon.svg";
export { default as protag } from "./general/pro-tag.png";
export { default as accPlusIcon } from "./general/plusIcon.svg";
export { default as accMinusIcon } from "./general/minusIcon.svg";
export { default as orangeRightArrow } from "./general/right-arrow-orange.svg";
export { default as shareIcon } from "./general/share.svg";
export { default as shareIconWhite } from "./general/share-icon.svg";
export { default as hamburgerLinkArrow } from "./general/header_right_arrow.svg";
export { default as floatingIcon } from "./general/floating_outer.svg";
export { default as floatingIcon1 } from "./general/floating_inner.svg";
export { default as reseticon } from "./general/reset-icon-orange.svg";
export { default as archinzaChatVideoNew } from "./general/archinza-botdesktopv02.mp4";
export { default as imgclose } from "./general/img-delete-icon.svg";
export { default as archinzaLabel } from "./general/archinza-label.svg";
export { default as leftarrowBlack } from "./general/business-left.svg";
export { default as brightarrowBlack } from "./general/business-right.svg";
export { default as errorFailed } from "./general/failed.svg";
export { default as errorSuccess } from "./general/sucess.svg";
export { default as logoutIcon } from "./general/logout.svg";

// homepage
export { default as logo } from "../images/homepage/archinza_logo_2.png";
export { default as mbLogo } from "../images/homepage/mb_archinza_logo_2.png";
export { default as homepageBanner } from "../images/homepage/banner_1.png";
export { default as mbHomepageBanner } from "../images/homepage/mb_banner_1.png";
export { default as chatImg } from "../images/homepage/chat_img_3.png";
export { default as mbChatImg } from "../images/homepage/mb_chat_img_3.png";
export { default as facebook } from "../images/homepage/facebook.png";
export { default as linkedIn } from "../images/homepage/linkedin.png";
export { default as insta } from "../images/homepage/insta.png";
export { default as searchIcon } from "../images/homepage/search-icon.svg";
export { default as reachIcon } from "../images/homepage/reach-icon.svg";
export { default as connectIcon } from "../images/homepage/connect-icon.svg";

// dashboard page
export { default as dashboardCall } from "../images/dashboard/call_icon.png";
export { default as dashboardEmail } from "../images/dashboard/email_icon.png";
export { default as dashboardLocation } from "../images/dashboard/location_icon.png";
export { default as dashboardEdit } from "../images/dashboard/edit_icon.png";
export { default as contactBg } from "../images/dashboard/contact_background.png";
export { default as editicon } from "../images/dashboard/edit-icon.svg";
export { default as editiconwhite } from "../images/dashboard/edit-icon-white.svg";
export { default as editiconorange } from "../images/dashboard/edit-icon-orange.svg";
export { default as changeRoleCup } from "../images/dashboard/cup.svg";

// registration form page
export { default as lightthemebackground } from "../images/registrationform/light-theme-background.png";
export { default as catalougeDelete } from "../images/registrationform/delete-icon.svg";

// contact us page
export { default as contactBanner } from "../images/contactus/contact_us_banner_1.jpg";

// faqs page
export { default as faqsBanner } from "../images/faqs/faqs_banner.jpg";

// blogs listing page
export { default as blogsListing } from "../images/blogs/blogsListing_banner.png";
export { default as rightArrowBlue } from "../images/blogs/right-arrow-blue.svg";

// blogs inner page
export { default as blogsInner } from "../images/blogs/blogsListing_banner.png";
export { default as blogsShareIcon } from "../images/blogs/share.svg";

// congratulations page
export { default as congraDesktopBanner } from "../images/congratulations/congrats_desktop_banner.jpg";
export { default as congraMobileBanner } from "../images/congratulations/congrats_mobile_banner.jpg";
export { default as congratCup } from "../images/congratulations/cup.svg";
export { default as congratCupWhite } from "../images/congratulations/cup_white.svg";

export { default as logoedit } from "../images/BusinessProfile/logo-edit.svg";
export { default as greentick } from "../images/BusinessProfile/green-tick.svg";
export { default as websiteiconb } from "../images/BusinessProfile/website-icon-b.svg";
export { default as linkediniconb } from "../images/BusinessProfile/linkedin-iconb.svg";
export { default as fbiconb } from "../images/BusinessProfile/fb-iconb.svg";
export { default as behanceiconb } from "../images/BusinessProfile/behance-iconb.svg";
export { default as addmoreIcon } from "../images/BusinessProfile/add-plus-icon.svg";
export { default as closeIcon } from "../images/BusinessProfile/close-icon.svg";
export { default as bookmarkIcon } from "../images/BusinessProfile/bookmark_icon.svg";

export let images = {
  archinzaFormBg: {
    image: require("./general/archinza-form-bg.png"),
    alt: "form bg",
  },
  formBg: {
    image: require("./general/form-bg.jpg"),
    alt: "bg",
  },
  editProfileBG: {
    image: require("./general/edit-back.jpg"),
    alt: "edit profile bg",
  },
  teammemberBg: {
    image: require("./teammember/team-member-bg.jpg"),
    alt: "team member bg",
  },
  homeBg: {
    image: require("./homepage/home-bg.jpg"),
    alt: "home bg",
  },
  mannequeenImg: {
    image: require("./homepage/mannequeen.png"),
    alt: "mannequeen",
  },
  PD633x915: {
    image: require("./homepage/633x915PD.png"),
    alt: "PD633915",
  },
  blogListing1: {
    image: require("./blogs/luke-van.png"),
    alt: "blogs",
  },
  blogListing2: {
    image: require("./blogs/ricardo-gomez.png"),
    alt: "blogs",
  },
  blogListing3: {
    image: require("./blogs/lance-anderson.png"),
    alt: "blogs",
  },
  hero1: {
    image: require("./blogs/luke-van-zyl-blogs-inner.png"),
    alt: "blogs",
  },
  businessprifilebg: {
    image: require("./BusinessProfile/business-prifile-bg.png"),
    alt: "business prifile bg",
  },
  brandlogo: {
    image: require("./BusinessProfile/brand-logo.png"),
    alt: "brand logo",
  },
  projectGallery01: {
    image: require("./BusinessProfile/project-gallery-01.jpg"),
    alt: "project gallery 01",
  },
};
