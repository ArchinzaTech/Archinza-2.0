import React, { lazy, Suspense } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import {
  businessAccessURL,
  homepageURL,
  privacypolicyURL,
  registrationFormURL,
  proAccessURL,
  teamAccesssURL,
  termsandconditionURL,
  businessFormFiveURL,
  regiserOTPURL,
  changeRoleURL,
  contactUsURL,
  faqsURL,
  comingsoonURL,
  editProfile,
  loginURL,
  resetPassURL,
  BlogsListingURL,
  BlogsInnerURL,
  congratulationsURL,
  accountCategoryURL,
  businessFormFiveLTURL,
  businessProfileURL,
  loginOtpURL,
  registrationBusinessURL,
  datatypesURL,
  congratulationsLightURL,
  dashboardURL,
  registrationBusinessOTPVerifyURL,
  registrationBusinessOTPURL,
} from "./components/helpers/constant-words";
import PrivacyPolicy from "./pages/PrivacyPolicy/PrivacyPolicy";
import Termsandcondition from "./pages/Terms&Condition/Terms&Condition";
import RegistrationForm from "./pages/RegistrationForm/RegistrationForm";
import TeamAccessForm from "./pages/TeamMember/TeamAccess/TeamAccessForm";
import FormFive from "./pages/FormFive/Form/FormFive";
import RegisterOTP from "./pages/RegistrationForm/RegisterOTP/RegisterOTP";
import ChangeRole from "./pages/ChangeRole/ChangeRole";
import BusinessAccess from "./pages/BusinessForm/BusinessAccess/BusinessAccess";
import ContactUs from "./pages/ContactUs/ContactUs";
import Faqs from "./pages/Faqs/Faqs";
import NotFound from "./pages/NotFound";
import Comingsoon from "./pages/Comingsoon/Comingsoon";
import Header from "./components/Header/Header";
import EditProfile from "./pages/EditProfile/EditProfile";
import Login from "./pages/Login/Login";
import ResetPassword from "./pages/ResetPassword/ResetPassword";
// import Home from "./pages/Home/Home";
import BlogsListing from "./pages/BlogsListing/BlogsListing";
import BlogsInner from "./pages/BlogsInner/BlogsInner";
import Congratulations from "./pages/Congratulations/Congratulations";
import AccountCategory from "./pages/RegistrationForm/AccountCategory/AccountCategory";
import FormFiveLightTheme from "./pages/FormFiveLightTheme/Form/FormFiveLightTheme";
import BusinessProfile from "./pages/BusinessProfile/BusinessProfile";
import LoginOTP from "./pages/LoginOTP/otp";
import BusinessAccountDetails from "./pages/BusinessAccountDetails/BusinessAccountDetails";
import DataTypes from "./pages/DataTypes/DataTypes";
import ProAccess from "./pages/ProAccessForm/ProAccess/ProAccess";
import CongratulationsLT from "./pages/CongratulationsLight/CongratulationsLT";
import { ProtectedRoute } from "./components/ProtectedRoute/ProtectedRoute";
import Dashboard from "./pages/Dashboard/Dashboard";
import BusinessRegisterOTP from "./pages/BusinessAccountDetails/RegisterOTP/BusinessRegisterOTP";

const LazyHome = lazy(() => import("./pages/Home/Home"));

const Routing = () => {
  return (
    <>
      <Header />
      <Routes>
        <Route
          path={homepageURL}
          element={
            <Suspense>
              <LazyHome />
            </Suspense>
          }
        />
        <Route path={comingsoonURL} element={<Comingsoon />} />
        <Route path={datatypesURL} element={<DataTypes />} />
        <Route path={changeRoleURL} element={<ChangeRole />} />
        <Route path={teamAccesssURL} element={<TeamAccessForm />} />
        <Route path={businessAccessURL} element={<BusinessAccess />} />
        <Route path={businessFormFiveURL} element={<FormFive />} />
        <Route path={businessFormFiveLTURL} element={<FormFiveLightTheme />} />

        <Route
          path={dashboardURL}
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route path={registrationFormURL} element={<RegistrationForm />} />
        <Route
          path={registrationBusinessURL}
          element={<BusinessAccountDetails />}
        />
        <Route
          path={registrationBusinessOTPURL}
          element={<BusinessRegisterOTP />}
        />
        <Route path={accountCategoryURL} element={<AccountCategory />} />
        <Route path={regiserOTPURL} element={<RegisterOTP />} />
        <Route
          path={editProfile}
          element={
            <ProtectedRoute>
              <EditProfile />
            </ProtectedRoute>
          }
        />
        <Route path={loginURL} element={<Login />} />
        <Route path={loginOtpURL} element={<LoginOTP />} />
        <Route path={resetPassURL} element={<ResetPassword />} />
        <Route path={contactUsURL} element={<ContactUs />} />
        <Route path={faqsURL} element={<Faqs />} />
        <Route path={privacypolicyURL} element={<PrivacyPolicy />} />
        <Route path={termsandconditionURL} element={<Termsandcondition />} />
        <Route path={BlogsListingURL} element={<BlogsListing />} />
        <Route path={BlogsInnerURL} element={<BlogsInner />} />
        <Route path={congratulationsURL} element={<Congratulations />} />
        <Route path={congratulationsLightURL} element={<CongratulationsLT />} />

        {/* PRO Access / Early Access */}
        <Route
          path={proAccessURL}
          element={
            <ProtectedRoute>
              <ProAccess />
            </ProtectedRoute>
          }
        />

        {/* Business Profile */}
        <Route path={businessProfileURL} element={<BusinessProfile />} />

        <Route exact path="/404" element={<NotFound />} />
        <Route path="*" element={<Navigate to="/404" />} />
      </Routes>
      {/* <FooterV2 /> */}
    </>
  );
};
export default Routing;
