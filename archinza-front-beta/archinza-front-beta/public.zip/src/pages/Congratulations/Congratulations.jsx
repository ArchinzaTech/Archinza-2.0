import React, { useEffect } from "react";
import "./congratulations.scss";
import { congratCup } from "../../images";
import GlowCta from "../../components/GlowCta/GlowCta";
import { Link } from "react-router-dom";
import { useWindowSize } from "react-use";
import FooterV2 from "../../components/FooterV2/FooterV2";
import ReactConfetti from "react-confetti";
import { dashboardURL } from "../../components/helpers/constant-words";
import BlinkingDots from "../../Animations/BlinkingDots/BlinkingDots";

const Congratulations = () => {
  const { width, height } = useWindowSize();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <BlinkingDots />
      <main className="congrat_main">
        {/* <img
          src={width > 767 ? congraDesktopBanner : congraMobileBanner}
          alt="background"
          className="blogslisting_background"
        /> */}
        <div className="confetti_wrapper">
          <ReactConfetti
            width={width - 50}
            height={height}
            colors={["#a67c00", "#bf9b30", "#ffbf00"]}
          />
        </div>

        <section className="congrat_sec1">
          <div className="my_container">
            <div className="content_wrapper">
              <img src={congratCup} alt="cup" className="cup" loading="lazy" />
              <h2 className="title">Congratulations!</h2>
              <p className="desc">
                You Are Eligible For Free Early <br /> Access To{" "}
                <span className="col_white">Archinza Pro!</span>
              </p>
              <div className="cta_wrapper">
                <GlowCta link={dashboardURL} text="Claim For Free Access Now" />
              </div>
              {/* <p className="text">
                <Link to={() => false} className="link">
                  Click here
                </Link>{" "}
                to Save & Exit
              </p> */}
            </div>
          </div>
        </section>

        <FooterV2 />
      </main>
    </>
  );
};

export default Congratulations;
