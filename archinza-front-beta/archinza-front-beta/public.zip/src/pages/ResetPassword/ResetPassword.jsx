import React, { useEffect, useState } from "react";
import "./resetpassword.scss";
import {
  checkiconWhite,
  otpicon,
  rightarrowwhite,
} from "../../images";
import FullWidthTextField from "../../components/TextField/FullWidthTextField";
import FooterV2 from "../../components/FooterV2/FooterV2";
import BlinkingDots from "../../Animations/BlinkingDots/BlinkingDots";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import OtpInput from "react-otp-input";
import { privacypolicyURL } from "../../components/helpers/constant-words";

const ResetPassword = () => {
  const [userState, setUserState] = useState("email");
  const [otpVal, setOtpVal] = useState("");
  const [resend, setResend] = useState(false);

  const handleotpChange = (otp) => {
    setOtpVal(otp);
  };

  const Msg = () => (
    <div className="otp_box">
      <img
        width={39}
        height={39}
        src={checkiconWhite}
        className="otp_resend_icon"
        loading="lazy"
        alt="icon"
      />
      <p className="title">OTP reshared</p>
    </div>
  );

  const resendHandler = () => {
    if (resend === false) {
      setResend(true);
      toast(<Msg />, {
        className: "otp_toast",
        position: toast.POSITION.TOP_CENTER,
        hideProgressBar: true,
        closeButton: false,
        autoClose: 1500,
      });
    } else {
      setResend(false);
    }
  };

  useEffect(() => {
    const resetButton = setTimeout(() => {
      setResend(false);
    }, 1000);
    return () => clearTimeout(resetButton);
  }, [resend]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <BlinkingDots />
      <main className="rpass_container">
        <section className="rpass_sec1">
          <div className="my_container">
            {userState === "email" && (
              <>
                <div className="text_container">
                  <h2 className="sub_title">Lorem Ipsum</h2>
                  <h1 className="title">Reset Your Password</h1>
                  <p className="notice mail_notice">
                    Applicants should be founders, CEOs or President of their
                    respective companies.
                  </p>
                </div>
                <div className="login_field_wrapper">
                  <div className="field_wrapper">
                    <FullWidthTextField label="Email ID*" type="email" />
                  </div>
                  <p className="terms_text">
                    By continuing, you agree to the terms of{" "}
                    <Link
                      to={privacypolicyURL}
                      className="link orange_text"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Archinza Policy.
                    </Link>
                  </p>
                  <div className="cta_wrapper zero_margin">
                    <div className="btn_wrapper">
                      <button
                        className="form_btn"
                        onClick={() => setUserState("otp")}
                      >
                        Sumbit
                        <img
                          src={rightarrowwhite}
                          alt="icon"
                          className="icon"
                          loading="lazy"
                        />
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}

            {userState === "otp" && (
              <>
                <div className="text_container">
                  <h2 className="sub_title">Lorem Ipsum</h2>
                  <h1 className="title">Enter OTP</h1>
                  <p className="notice otp_notice">
                    Please check your inbox for the OTP to validate your
                    account.
                    <br />
                    <br />
                    Do not close this page. Please check your inbox for the OTP
                    to validate your account. If you do not see it please check
                    your spam folder. Any issues? Please contact us at{" "}
                    <a href="mailto:applications@archinza.com">
                      applications@archinza.com
                    </a>
                  </p>
                </div>
                <div className="icon_notice_wrapper">
                  <div className="icon_wrapper">
                    <img
                      width={81}
                      height={81}
                      src={otpicon}
                      alt="icon"
                      className="icon"
                      loading="lazy"
                    />
                  </div>
                  <p className="description">Enter OTP</p>
                </div>
                <div className="login_field_wrapper">
                  <div className="otp_wrapper">
                    <div className="otp_box_wrapper">
                      <OtpInput
                        value={otpVal}
                        onChange={handleotpChange}
                        numInputs={6}
                        containerStyle="otp_input_wrapper"
                        inputStyle="otp_input"
                        isInputNum={true}
                        focusStyle="otp_focused"
                        shouldAutoFocus
                      />
                    </div>
                    <div className="btn_wrapper">
                      <button
                        className="form_btn"
                        onClick={() => {
                          setUserState("reset");
                        }}
                      >
                        Verify
                        <img
                          src={rightarrowwhite}
                          alt="icon"
                          className="icon"
                          loading="lazy"
                        />
                      </button>
                      <button className="back_button" onClick={resendHandler}>
                        {resend === false ? "Resend OTP" : "Resending OTP"}
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}

            {userState === "reset" && (
              <>
                <div className="text_container">
                  <h2 className="sub_title">Lorem Ipsum</h2>
                  <h1 className="title">Reset Your Password</h1>
                </div>
                <div className="login_field_wrapper">
                  <div className="field_wrapper">
                    <FullWidthTextField label="New password*" type="password" />
                    <p className="reset_notice">
                      your password should be at least 8 characters
                    </p>
                  </div>
                  <div className="field_wrapper">
                    <FullWidthTextField
                      label="Re-enter password*"
                      type="password"
                    />
                    <p className="error"></p>
                    <p className="terms_text">
                      By continuing, you agree to the terms of{" "}
                      <Link
                        to={privacypolicyURL}
                        className="link orange_text"
                        target="_blank"
                        rel="noreferrer"
                      >
                        Archinza Policy.
                      </Link>
                    </p>
                  </div>

                  <div className="cta_wrapper">
                    <div className="btn_wrapper zero_margin">
                      <button
                        className="form_btn"
                        onClick={() => setUserState("email")}
                      >
                        Reset Password
                        <img
                          src={rightarrowwhite}
                          alt="icon"
                          className="icon"
                          loading="lazy"
                        />
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </section>
        <FooterV2 />
      </main>
    </>
  );
};
export default ResetPassword;
