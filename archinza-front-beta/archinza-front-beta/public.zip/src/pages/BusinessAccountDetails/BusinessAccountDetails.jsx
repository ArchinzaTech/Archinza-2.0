import React, { useCallback, useEffect, useState } from "react";
import style from "./businessAccountDetails.module.scss";
import { errorFailed, errorSuccess, rightarrowblack } from "../../images";
import { countries } from "../../db/dataTypesData";
import FullWidthTextField from "../../components/TextField/FullWidthTextField";
import AutoCompleteField from "../../components/AutoCompleteField/AutoCompleteField";
import CountryCodeDropdown from "../../components/CountryCodeDropdown/CountryCodeDropdown";
import FooterV2 from "../../components/FooterV2/FooterV2";
import { Link, useNavigate } from "react-router-dom";
import LightThemeBackground from "../../Animations/LightThemeBackground/LightThemeBackground";
import {
  privacypolicyURL,
  regiserOTPURL,
  registrationBusinessOTPURL,
} from "../../components/helpers/constant-words";
import config from "../../config/config";
import http from "../../helpers/http";
import axios from "axios";
import { debounce } from "lodash";
import Joi from "joi";
import helper from "../../helpers/helper";

const BusinessAccountDetails = () => {
  const navigate = useNavigate();

  const [values, setValues] = useState({
    business_name: "",
    email: "",
    password: "",
    country_code: "91",
    phone: "",
    whatsapp_country_code: "91",
    whatsapp_no: "",
    country: "",
    city: "",
    pincode: "",
    username: "",
  });

  const [formError, setFormError] = useState({});
  const [codes, setCodes] = useState([]);
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);
  const [isWASame, setIsWASame] = useState(false);
  const [usernameStatus, setUsernameStatus] = useState(null);
  const [usernameMsg, setUsernameMsg] = useState("");
  const joiOptions = config.joiOptions;

  const base_url = config.api_url; //without trailing slash

  const handleChange = (e) => {
    if (e.target.name == "phone" && isWASame == true) {
      setValues((prevState) => {
        return {
          ...prevState,
          ["whatsapp_no"]: e.target.value,
          ["whatsapp_country_code"]: prevState.country_code,
        };
      });
    }

    if (e.target.name == "username") {
      debouncedCheckUsername(e.target.value);
    }
    setValues((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
      };
    });
  };
  const handleWAChange = (e) => {
    const { value, checked } = e.target;
    setValues((prevState) => {
      return {
        ...prevState,
        ["whatsapp_no"]: checked ? prevState.phone : "",
        ["whatsapp_country_code"]: checked ? prevState.country_code : "",
      };
    });

    setIsWASame(checked);
    // if (checked) {
    // }
    // else {
    //   setValues((prevState) => {
    //     return {
    //       ...prevState,
    //       ["whatsapp_no"]: "",
    //       ["whatsapp_country_code"]: "",
    //     };
    //   });

    //   setIsWASame(false);
    // }
  };

  const validate = async (data) => {
    let schemaObj = {
      business_name: Joi.string().trim().required().label("Name of Business"),
      email: Joi.string()
        .email({ tlds: { allow: false } })
        .required()
        .label("Email"),
      password: Joi.string().min(8).required().label("Account Password"),
      country_code: Joi.string().trim().required().label("Code"),
      phone: Joi.string().trim().required().label("Phone No"),
      whatsapp_no: Joi.string().trim().required().label("WhatsApp number"),
      whatsapp_country_code: Joi.string()
        .trim()
        .required()
        .label("Whatsapp Country Code"),
      country: Joi.string().trim().required().label("Country"),
      username: Joi.string().min(4).trim().required().label("Account Username"),
    };

    if (data.country == "India" || data.country == "") {
      schemaObj = {
        ...schemaObj,
        city: Joi.string().trim().required().label("City"),
        pincode: Joi.number().required().label("Pincode"),
      };
    }

    const schema = Joi.object(schemaObj).options({ allowUnknown: true });

    const { error } = schema.validate(data, joiOptions);

    const errors = {};

    if (error) {
      error.details.map((field) => {
        errors[field.path[0]] = field.message;
        return true;
      });
    }

    // validating unique email
    // if (data.email) {
    //   // const result = await helper.validateEmail(data.email, "PersonalAccount");

    //   if (result === false) {
    //     errors["email"] = `This email is already in use.`;
    //   }
    // }
    // validating unique phone
    // if (data.email) {
    //   const result = await helper.validatePhone(
    //     data.country_code,
    //     data.phone,
    //     "PersonalAccount"
    //   );

    //   if (result === false) {
    //     errors["phone"] = `This phone number is already in use.`;
    //   }
    // }

    return errors ? errors : null;
  };
  const handleSelectChange = (value, fieldName) => {
    setValues((prevState) => {
      return {
        ...prevState,
        [fieldName]: value,
      };
    });
  };
  const fetchCodes = async () => {
    const { data } = await http.get(base_url + "/general/countries/codes");

    if (data) {
      setCodes(data);
    }
  };
  const fetchCountires = async () => {
    const { data } = await http.get(base_url + "/general/countries");

    if (data) {
      setCountries(data);
    }
  };
  const fetchCities = async () => {
    const country_id = 101;
    const { data } = await http.get(
      base_url + "/general/cities-by-country/" + country_id
    );

    if (data) {
      setCities(data);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let errors = await validate(values);
    console.log(values);
    setFormError(errors);
    if (Object.keys(errors).length) {
      helper.scroll(helper.getFirstError(errors));
      return;
    }

    const data = await http.post(base_url + "/business/signup", values);
    if (data) {
      navigate(registrationBusinessOTPURL, {
        state: values,
      });

      // window.scrollTo(0, 0);
      // redirect
      // setValues({ email: "" });
      // setisMsgVisible(true);
    }
  };

  const debouncedCheckUsername = useCallback(
    debounce((username) => handleUsernameAvailability(username), 1000),
    []
  );
  const handleUsernameAvailability = async (username) => {
    const data = await http.post(base_url + "/business/check-username", {
      username: username,
    });
    if (data.data.available) {
      setUsernameStatus("success");
      setUsernameMsg("Valid username");
    } else {
      setUsernameStatus("failure");
      setUsernameMsg("This username already exists");
    }
  };

  useEffect(() => {
    fetchCodes();
    fetchCountires();
    fetchCities();
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      <LightThemeBackground />
      <section className={style.bus_sec1}>
        <div className="my_container">
          <div className={style.text_container}>
            <h1 className={style.title}>Your Business Account Details</h1>
            {/* <p className={style.description}></p> */}
          </div>
          <div className={`${style.steps} ${style.rstep1}`}>
            <div className={style.brand_box}>
              <div className={style.business_details}>
                <div className={`row`}>
                  <div className={`col-md-6 ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <FullWidthTextField
                        lightTheme
                        key="Name of Business*"
                        label="Name of Business*"
                        name="business_name"
                        value={values.business_name}
                        onChange={handleChange}
                      />
                      <div id="business_name_error">
                        {formError.business_name && (
                          <p className="error">{formError.business_name}</p>
                        )}
                      </div>

                      {/* <p className={style.error}>
                        Error messsage here error messsage
                      </p> */}
                    </div>
                  </div>
                  {/* <div className={`col-md-6 ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <FullWidthTextField
                        lightTheme
                        key="Name of POC For Business / Firm*"
                        label="Name of POC For Business / Firm*"
                      />
                      <p className={style.error}>
                        Error messsage here error messsage
                      </p>
                    </div>
                  </div> */}
                  <div className={`col-md-6 ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <div className="row">
                        <div className="col-4 col-sm-4 col-md-4 ps-0">
                          <div className={style.country_code}>
                            <CountryCodeDropdown
                              lightTheme
                              key="country_code"
                              textLabel="Code*"
                              data={codes}
                              onChange={(e, value) => {
                                handleSelectChange(
                                  value.phone_code?.toString(),
                                  "country_code"
                                );
                              }}
                              defaultValue={{
                                name: "India",
                                iso3: "IND",
                                phone_code: "91",
                              }}
                            />
                          </div>
                        </div>
                        <div className="col-8 col-sm-8 col-md-8 pe-0">
                          <div className={style.country_code}>
                            <FullWidthTextField
                              lightTheme
                              key="phone"
                              label="Phone No*"
                              name="phone"
                              type="number"
                              value={values.phone}
                              onChange={handleChange}
                            />
                          </div>
                        </div>
                      </div>
                      <div id="phone_error">
                        {formError.country_code ||
                          (formError.phone && (
                            <p className="error">
                              {formError.country_code || formError.phone}
                            </p>
                          ))}
                      </div>
                      {/* <p className={style.error}>
                        Error messsage here error messsage
                      </p> */}
                    </div>
                  </div>
                  <div className={`col-md-6 ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <div className="row">
                        <div className="col-4 col-sm-4 col-md-4 ps-0">
                          <div className={style.country_code}>
                            <CountryCodeDropdown
                              lightTheme
                              key="whatsapp_country_code"
                              textLabel="Whatsapp Country Code*"
                              data={codes}
                              onChange={(e, value) => {
                                handleSelectChange(
                                  value.phone_code?.toString(),
                                  "whatsapp_country_code"
                                );
                              }}
                              defaultValue={{
                                name: "India",
                                iso3: "IND",
                                phone_code: "91",
                              }}
                            />
                          </div>
                        </div>
                        <div className="col-8 col-sm-8 col-md-8 pe-0">
                          <div className={style.country_code}>
                            <FullWidthTextField
                              lightTheme
                              key="WhatsApp number"
                              label="WhatsApp number*"
                              type="number"
                              name="whatsapp_no"
                              value={values.whatsapp_no}
                              onChange={handleChange}
                            />
                          </div>
                        </div>
                      </div>
                      <div id="phone_error">
                        {formError.country_code ||
                          (formError.whatsapp_no && (
                            <p className="error">
                              {formError.whatsapp_country_code ||
                                formError.whatsapp_no}
                            </p>
                          ))}
                      </div>
                      {/* <p className={style.error}>
                        Error messsage here error messsage
                      </p> */}
                    </div>
                    <div className={style.checkbox_wrapper}>
                      <label className={style.checkbox_label} htmlFor="sameas">
                        <input
                          type="checkbox"
                          className={style.check_box}
                          checked={isWASame}
                          onChange={handleWAChange}
                          id="sameas"
                        />
                        Same as phone number
                      </label>
                    </div>
                  </div>
                  <div className={`col-md-6 ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <FullWidthTextField
                        lightTheme
                        key="Email ID"
                        label="Email ID"
                        name="email"
                        value={values.email}
                        onChange={handleChange}
                      />
                      <div id="email_error">
                        {formError.email && (
                          <p className="error">{formError.email}</p>
                        )}
                      </div>

                      {/* <p className={style.error}>
                        Error messsage here error messsage
                      </p> */}
                    </div>
                  </div>
                  <div className={`col-md-6  ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <AutoCompleteField
                        lightTheme
                        key="country"
                        textLabel="Country*"
                        data={countries}
                        onChange={(e, option) => {
                          handleSelectChange(option.value, "country");
                        }}
                      />
                      <div id="country_error">
                        {formError.country && (
                          <p className="error">{formError.country}</p>
                        )}
                      </div>

                      {/* <p className={style.error}>
                        Error messsage here error messsage
                      </p> */}
                    </div>
                  </div>
                  <div className={`col-md-6  ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <AutoCompleteField
                        lightTheme
                        textLabel="City*"
                        data={cities}
                        getOptionLabel={(option) => option.name}
                        onChange={(e, value) => {
                          handleSelectChange(value.name, "city");
                        }}
                      />
                      <div id="city_error">
                        {formError.city && (
                          <p className="error">{formError.city}</p>
                        )}
                      </div>

                      {/* <p className={style.error}>
                        Error messsage here error messsage
                      </p> */}
                    </div>
                  </div>
                  <div className={`col-md-6  ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <FullWidthTextField
                        lightTheme
                        type="number"
                        name="pincode"
                        label="Pincode*"
                        value={values.pincode}
                        onChange={handleChange}
                      />
                      <div id="pincode_error">
                        {formError.pincode && (
                          <p className="error">{formError.pincode}</p>
                        )}
                      </div>

                      {/* <p className={style.error}>
                        Error messsage here error messsage
                      </p> */}
                    </div>
                  </div>
                  <div className={`col-md-6  ${style.rstep01_col}`}></div>
                  <div className={`col-md-6  ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <div className={style.input_wrapper}>
                        <FullWidthTextField
                          lightTheme
                          name="username"
                          type="text"
                          value={values.username}
                          label="Account Username*"
                          onChange={handleChange}
                        />
                        <img
                          className={style.val_icon}
                          src={errorFailed}
                          alt="failed"
                          style={{
                            display:
                              usernameStatus === "failure" ? "block" : "none",
                          }}
                        />
                        <img
                          className={style.val_icon}
                          src={errorSuccess}
                          alt="success"
                          style={{
                            display:
                              usernameStatus === "success" ? "block" : "none",
                          }}
                        />
                      </div>
                      <p
                        className={`${
                          usernameStatus === "success"
                            ? style.success_text
                            : style.error_text
                        }`}
                      >
                        {usernameMsg}
                      </p>
                      <div id="username_error">
                        {formError.username && (
                          <p className="error">{formError.username}</p>
                        )}
                      </div>

                      {/* <p className={style.error}>
                        Error messsage here error messsage
                      </p> */}
                    </div>
                  </div>
                  <div className={`col-md-6  ${style.rstep01_col}`}>
                    <div className={style.field_wrapper}>
                      <FullWidthTextField
                        lightTheme
                        type="password"
                        label="Account Password*"
                        name="password"
                        value={values.password}
                        onChange={handleChange}
                      />
                      <p className="pass_help">
                        Your password should be at least 8 characters
                      </p>
                      <div id="password_error">
                        {formError.password && (
                          <p className="error">{formError.password}</p>
                        )}
                      </div>

                      {/* <p className={`${style.error_text}`}>
                        Your username should be at least 4 characters
                      </p> */}
                      {/* <p className={style.error}>
                        Error messsage here error messsage
                      </p> */}
                    </div>
                  </div>
                </div>
                <p className={style.terms_text}>
                  By continuing, you agree to the terms of{" "}
                  <Link
                    to={privacypolicyURL}
                    className={style.link}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Archinza Policy.
                  </Link>
                </p>
                <div className={style.next_logout}>
                  <div className={style.cta_wrapper}>
                    <div className={style.next_button} onClick={handleSubmit}>
                      <div className={style.text}>Send OTP</div>
                      <img
                        src={rightarrowblack}
                        alt="icon"
                        className={style.icon}
                        loading="lazy"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <FooterV2 />
    </>
  );
};

export default BusinessAccountDetails;
