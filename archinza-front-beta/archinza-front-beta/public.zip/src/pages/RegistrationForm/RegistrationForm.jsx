import React, { useEffect, useState } from "react";
import "./registrationform.scss";
import RadioButton from "../../components/RadioButton/RadioButton";
import FullWidthTextField from "../../components/TextField/FullWidthTextField";
import CountryCodeDropdown from "../../components/CountryCodeDropdown/CountryCodeDropdown";
import { Link, useNavigate } from "react-router-dom";
import { rightarrowwhite } from "../../images";
import { useWindowSize } from "react-use";
import FooterV2 from "../../components/FooterV2/FooterV2";
import AutoCompleteField from "../../components/AutoCompleteField/AutoCompleteField";
import { countries2 } from "../../db/dataTypesData";
import BlinkingDots from "../../Animations/BlinkingDots/BlinkingDots";
import {
  privacypolicyURL,
  regiserOTPURL,
} from "../../components/helpers/constant-words";
import config from "../../config/config";

import Joi from "joi";
import http from "../../helpers/http";
import helper from "../../helpers/helper";

const RegistrationForm = () => {
  const { width } = useWindowSize();

  const navigate = useNavigate();

  const [values, setValues] = useState({
    user_type: "",
    name: "",
    email: "",
    password: "",
    country_code: "91",
    phone: "",
    whatsapp_no: "",
    country: "India",
    city: "",
    pincode: "",
  });
  const [formError, setFormError] = useState({});
  const [codes, setCodes] = useState([]);
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);
  const [isWASame, setIsWASame] = useState(false);
  // const [cities, setCities] = useState([]);

  const joiOptions = config.joiOptions;

  const base_url = config.api_url; //without trailing slash

  const handleChange = (e) => {
    if (e.target.name == "phone" && isWASame == true) {
      setValues((prevState) => {
        return {
          ...prevState,
          ["whatsapp_no"]: e.target.value,
        };
      });
    }

    setValues((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
      };
    });
  };
  const handleSelectChange = (value, fieldName) => {
    setValues((prevState) => {
      return {
        ...prevState,
        [fieldName]: value,
      };
    });
  };

  const handleWAChange = (e) => {
    const { value, checked } = e.target;

    if (checked) {
      setValues((prevState) => {
        return {
          ...prevState,
          ["whatsapp_no"]: values.phone,
        };
      });

      setIsWASame(true);
    } else {
      setValues((prevState) => {
        return {
          ...prevState,
          ["whatsapp_no"]: "",
        };
      });

      setIsWASame(false);
    }
  };

  const validate = async (data) => {
    let schemaObj = {
      user_type: Joi.string().trim().required().messages({
        "string.empty": `Please choose your role to proceed`,
      }),
      name: Joi.string().trim().required().label("Name"),
      email: Joi.string()
        .email({ tlds: { allow: false } })
        .required()
        .label("Email"),
      password: Joi.string().min(8).required().label("Password"),
      country_code: Joi.string().trim().required().label("Code"),
      phone: Joi.string().trim().required().label("Phone"),
      whatsapp_no: Joi.string().trim().required().label("WhatsApp number"),
      country: Joi.string().trim().required().label("Country"),
    };

    if (data.country == "India") {
      schemaObj.city = Joi.string().trim().required().label("City");

      schemaObj.pincode = Joi.number().required().label("Pincode");
    }

    const schema = Joi.object(schemaObj).options({ allowUnknown: true });

    const { error } = schema.validate(data, joiOptions);

    const errors = {};

    if (error) {
      error.details.map((field) => {
        errors[field.path[0]] = field.message;
        return true;
      });
    }

    // validating unique email
    if (data.email) {
      const result = await helper.validateEmail(data.email, "PersonalAccount");

      if (result === false) {
        errors["email"] = `This email is already in use.`;
      }
    }
    // validating unique phone
    if (data.email) {
      const result = await helper.validatePhone(
        data.country_code,
        data.phone,
        "PersonalAccount"
      );

      if (result === false) {
        errors["phone"] = `This phone number is already in use.`;
      }
    }

    return errors ? errors : null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let errors = await validate(values);

    setFormError(errors);
    if (Object.keys(errors).length) {
      helper.scroll(helper.getFirstError(errors));
      return;
    }

    const data = await http.post(base_url + "/personal/signup", values);

    if (data) {
      navigate(regiserOTPURL, {
        state: values,
      });

      // window.scrollTo(0, 0);
      // redirect
      // setValues({ email: "" });
      // setisMsgVisible(true);
    }
  };

  const fetchCodes = async () => {
    const { data } = await http.get(base_url + "/general/countries/codes");

    if (data) {
      setCodes(data);
    }
  };
  const fetchCountires = async () => {
    const { data } = await http.get(base_url + "/general/countries");

    if (data) {
      setCountries(data);
    }
  };
  const fetchCities = async () => {
    const country_id = 101;
    const { data } = await http.get(
      base_url + "/general/cities-by-country/" + country_id
    );

    if (data) {
      setCities(data);
    }
  };
  useEffect(() => {
    fetchCodes();
    fetchCountires();
    fetchCities();
  }, []);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <BlinkingDots />
      <main className="reg_main">
        <section className="reg_sec1">
          <div className="my_container">
            <div className="text_container">
              <p className="head_text">Get early access</p>
              <h1 className="heading">Tell us about yourself</h1>
              <h2 className="sub_heading">
                Your role in the Design & Build industry
              </h2>
              <p className="choose_text">Choose one</p>
              <div id="user_type_error">
                {formError.user_type && (
                  <p className="error top_error">{formError.user_type}</p>
                )}
              </div>
            </div>

            <form className="form_container" onSubmit={handleSubmit} noValidate>
              <ul className="radio_container radio_container_form">
                <RadioButton
                  label="Business | Firm Owner"
                  labelId="business-firm-owner"
                  name="user_type"
                  value="BO"
                  checked={values.user_type === "BO"}
                  onChange={handleChange}
                />
                <RadioButton
                  label="Student"
                  labelId="student"
                  name="user_type"
                  value="ST"
                  checked={values.user_type === "ST"}
                  onChange={handleChange}
                />
                <RadioButton
                  label="Team Member"
                  labelId="team-member"
                  name="user_type"
                  value="TM"
                  checked={values.user_type === "TM"}
                  onChange={handleChange}
                />
                <RadioButton
                  label="Design Enthusiast"
                  labelId="design-enthusiast"
                  name="user_type"
                  value="DE"
                  checked={values.user_type === "DE"}
                  onChange={handleChange}
                />
              </ul>

              <div className="row form_row">
                <div className={`col-md-6 form_col ${width > 992 && "ps-0"}`}>
                  <div className="field_wrapper field_wrapper_mobile">
                    <FullWidthTextField
                      label="Your full name?*"
                      name="name"
                      value={values.name}
                      onChange={handleChange}
                    />
                    <div id="name_error">
                      {formError.name && (
                        <p className="error">{formError.name}</p>
                      )}
                    </div>
                  </div>
                </div>
                <div className={`col-md-6 form_col ${width > 992 && "pe-0"}`}>
                  <div className="field_wrapper">
                    <FullWidthTextField
                      label="E-mail*"
                      type="email"
                      name="email"
                      value={values.email}
                      onChange={handleChange}
                    />
                    <div id="email_error">
                      {formError.email && (
                        <p className="error">{formError.email}</p>
                      )}
                    </div>
                  </div>
                </div>
                <div className={`col-md-6 form_col ${width > 992 && "ps-0"}`}>
                  <div className="field_wrapper">
                    <FullWidthTextField
                      label="Set Password*"
                      type="password"
                      name="password"
                      value={values.password}
                      onChange={handleChange}
                    />
                    <p className="pass_help">
                      Your password should be at least 8 characters
                    </p>
                    <div id="password_error">
                      {formError.password && (
                        <p className="error">{formError.password}</p>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-md-6 form_col pe-0">
                  <div className="field_wrapper">
                    <div className="row">
                      <div className="col-4 col-sm-4 col-md-4 ps-0">
                        <div className="field_wrapper_1">
                          <CountryCodeDropdown
                            key="country_code"
                            textLabel="Code*"
                            data={codes}
                            onChange={(e, value) => {
                              handleSelectChange(
                                value.phone_code,
                                "country_code"
                              );
                            }}
                            defaultValue={{
                              name: "India",
                              iso3: "IND",
                              phone_code: "91",
                            }}
                          />
                        </div>
                      </div>
                      <div
                        // className={`col-8 col-sm-8 col-md-8 ${
                        //   width > 992 ? "pe-0" : "ps-0"
                        // } ${width <= 575 && "mobile_stack"}`}
                        className={`col-8 col-sm-8 col-md-8 ${
                          width > 992 ? "pe-0" : "ps-0"
                        }`}
                      >
                        <div className="field_wrapper_1">
                          <FullWidthTextField
                            label="Phone*"
                            type="tel"
                            name="phone"
                            value={values.phone}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                    <div id="phone_error">
                      {formError.country_code ||
                        (formError.phone && (
                          <p className="error">
                            {formError.country_code || formError.phone}
                          </p>
                        ))}
                    </div>
                  </div>
                </div>
                <div className={`col-md-6 form_col ${width > 992 && "ps-0"}`}>
                  <div className="field_wrapper">
                    <div className="row">
                      <div className="col-4 col-sm-4 col-md-4 ps-0">
                        <div className="field_wrapper_1">
                          <CountryCodeDropdown
                            key="country_code"
                            textLabel="Code*"
                            data={codes}
                            onChange={(e, value) => {
                              handleSelectChange(
                                value.phone_code,
                                "country_code"
                              );
                            }}
                            defaultValue={{
                              name: "India",
                              iso3: "IND",
                              phone_code: "91",
                            }}
                          />
                        </div>
                      </div>
                      <div
                        className={`col-8 col-sm-8 col-md-8 ${
                          width > 992 ? "pe-0" : "ps-0"
                        }`}
                      >
                        <div className="field_wrapper_1">
                          <FullWidthTextField
                            label="WhatsApp number*"
                            type="tel"
                            name="whatsapp_no"
                            value={values.whatsapp_no}
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>
                    <div id="whatsapp_no_error">
                      {formError.whatsapp_no && (
                        <p className="error">{formError.whatsapp_no}</p>
                      )}
                    </div>
                  </div>
                  <div
                    className={`checkbox_wrapper ${
                      formError.whatsapp_no && "error"
                    }`}
                  >
                    <label className="checkbox_label">
                      <input
                        type="checkbox"
                        className="check_box"
                        checked={isWASame}
                        onChange={handleWAChange}
                      />
                      Same as phone number
                    </label>
                  </div>
                </div>
                <div className={`col-md-6 form_col ${width > 992 && "pe-0"}`}>
                  <div className="field_wrapper">
                    <AutoCompleteField
                      key="country"
                      textLabel="Country*"
                      data={countries}
                      onChange={(e, option) => {
                        handleSelectChange(option.value, "country");
                      }}
                      defaultValue={{
                        value: "India",
                        label: "India",
                      }}
                    />
                    <div id="country_error">
                      {formError.country && (
                        <p className="error">{formError.country}</p>
                      )}
                    </div>
                  </div>
                </div>
                {values?.country === "India" && (
                  <>
                    <div
                      className={`col-md-6 form_col ${width > 992 && "ps-0"}`}
                    >
                      <div className="field_wrapper">
                        <AutoCompleteField
                          key="city"
                          textLabel="City*"
                          data={cities}
                          getOptionLabel={(option) => option.name}
                          onChange={(e, value) => {
                            handleSelectChange(value.name, "city");
                          }}
                        />
                        <div id="city_error">
                          {formError.city && (
                            <p className="error">{formError.city}</p>
                          )}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`col-md-6 form_col ${width > 992 && "pe-0"}`}
                    >
                      <div className="field_wrapper">
                        <FullWidthTextField
                          type="tel"
                          label="Pincode*"
                          name="pincode"
                          value={values.pincode}
                          onChange={handleChange}
                        />
                        <div id="pincode_error">
                          {formError.pincode && (
                            <p className="error">{formError.pincode}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </>
                )}
                <div className={`col-md-12 form_col ${width > 992 && "p-0"}`}>
                  <div className="privacy_checbox">
                    By continuing, you agree to <br />
                    the terms of&nbsp;
                    <Link
                      to={privacypolicyURL}
                      className="policy_link"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Archinza Policy
                    </Link>
                    .
                  </div>
                </div>
                <div className={`col-md-12 form_col ${width > 992 && "p-0"}`}>
                  <div className="btn_wrapper">
                    <button className="form_btn">
                      Get OTP To Connect
                      <img
                        src={rightarrowwhite}
                        alt="icon"
                        className="icon"
                        loading="lazy"
                      />
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </section>
        <FooterV2 />
      </main>
    </>
  );
};

export default RegistrationForm;
