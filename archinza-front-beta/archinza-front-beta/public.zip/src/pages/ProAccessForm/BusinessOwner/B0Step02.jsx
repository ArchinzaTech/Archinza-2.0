import React, { useEffect, useState } from "react";
import style from "../ProAccess/proaccess.module.scss";
import LogoutText from "../../../components/LogoutText/LogoutText";
import { rightarrowwhite } from "../../../images";
// import CheckboxButton from "../../../components/CheckboxButton/CheckboxButton";
import http from "../../../helpers/http";
import Joi from "joi";
import { useProAccess } from "../../../context/ProAccess/ProAccessState";

import config from "../../../config/config";
import RadioButton from "../../../components/RadioButton/RadioButton";
import { useNavigate } from "react-router-dom";
import { dashboardURL } from "../../../components/helpers/constant-words";
import { useWindowSize } from "react-use";
import { useAuth } from "../../../context/Auth/AuthState";
// const concernArr = [
//   "Finding Leads/Clients",
//   "Finding People/Products",
//   "Marketing",
//   "Networking",
//   "Business Operations",
//   "All of the Above",
// ];

const BOStep02 = ({
  previousStep,
  nextStep,
  currentStep,
  totalSteps,
  progressStatus,
  isActive,
}) => {
  // =============== VARIABLE & STATES  ===========================

  const [values, setValues] = useState({});
  const [formError, setFormError] = useState({});

  const [options, setOptions] = useState([]);
  const { width } = useWindowSize();
  const base_url = config.api_url;
  const joiOptions = config.joiOptions;

  const ProAccess = useProAccess();
  const navigate = useNavigate();
  const auth = useAuth();

  // =============== FUNCTIONS  ===========================

  const handleChange = (e) => {
    setValues((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
      };
    });
  };

  const validate = async (data) => {
    let schemaObj = {
      bo_unmet_needs: Joi.string().required().label("Duration"),
    };

    const schema = Joi.object(schemaObj).options({ allowUnknown: true });

    const { error } = schema.validate(data, joiOptions);

    const errors = {};

    if (error) {
      error.details.map((field) => {
        errors[field.path[0]] = field.message;
        return true;
      });
    }

    return errors ? errors : null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    let form_values = values;

    let errors = await validate(form_values);

    setFormError(errors);
    if (Object.keys(errors).length) {
      return;
    }
    let status = "completed";

    const data = await http.put(
      `${base_url}/pro-access/update/${ProAccess?.data?._id}`,
      {
        ...form_values,
        status: status,
      }
    );

    if (data) {
      ProAccess.update({ ...ProAccess.data, ...form_values, status: status });

      navigate(dashboardURL);

      window.scrollTo(0, 0);
    }
  };
  // =============== HTML RENDERING  ===========================

  const optionsList = options?.map((option, i) => (
    <React.Fragment key={`business-owner-02-${i}`}>
      <RadioButton
        extraSpace={true}
        label={option.label}
        labelId={`business-owner-02-${i}`}
        name="bo_unmet_needs"
        value={option.value}
        checked={values.bo_unmet_needs === option.value}
        onChange={handleChange}
      />
    </React.Fragment>
  ));
  // =============== DATA FETCHING  ===========================

  const fetchOptions = async (question_key) => {
    const res = await http.get(`${base_url}/options/${question_key}`);

    const data = res?.data || null;

    if (data) {
      setOptions(data?.options);
    }
  };
  // =============== SIDE EFFECTS  ===========================

  useEffect(() => {
    fetchOptions("bo_unmet_needs");
  }, []);

  useEffect(() => {
    setValues({
      bo_unmet_needs: ProAccess?.data?.bo_unmet_needs,
    });
  }, [currentStep]);

  useEffect(() => {
    if (isActive) {
      progressStatus((2 / 2) * 100);
    }
  }, [isActive]);

  return (
    <>
      <div className={style.text_container}>
        <button className={`${style.dashboard_btn} ${style.businessFirm_pill}`}>
          Business | Firm owner
        </button>
        <h1 className={style.title}>
        {auth?.user?.name?.split(" ")[0]}, as a business/firm owner {width > 600 && <br />}what is
          your largest concern I unmet need...
        </h1>
        <p
          className={`${style.description} ${
            formError?.bo_unmet_needs && style.active
          }`}
        >
          Choose one
        </p>
        {formError?.bo_unmet_needs && (
          <p className={`error ${style.error}`}>{formError?.bo_unmet_needs}</p>
        )}
      </div>
      <form onSubmit={handleSubmit}>
        <div className={`${style.steps} ${style.step02}`}>
          <ul className={style.step02_ul}>{optionsList}</ul>
        </div>

        {/* <div className={`${style.checkbox_wrapper}`}>
        <label className={style.checkbox_label} htmlFor="sameas">
          <input type="checkbox" className={style.check_box} id="sameas" />
          Select All
        </label>
      </div> */}

        <div className={`${style.next_logout} ${style.next_logout_step02}`}>
          <div className={style.cta_wrapper}>
            <button
              className={style.next_button}
              // onClick={() => {
              //   nextStep();
              //   window.scrollTo(0, 0);
              // }}
            >
              <div className={style.text}>Submit</div>
              <img
                src={rightarrowwhite}
                alt="icon"
                className={style.icon}
                loading="lazy"
              />
            </button>
            <div
              className={style.back_button}
              onClick={() => {
                previousStep(1);
                window.scrollTo(0, 0);
              }}
            >
              Back
            </div>
          </div>
          <LogoutText />
        </div>
      </form>
    </>
  );
};

export default BOStep02;
