import React, { useEffect, useState } from "react";
import "./login.scss";
import { checkiconWhite, rightarrowwhite } from "../../images";
import CountryCodeDropdown from "../../components/CountryCodeDropdown/CountryCodeDropdown";
import FullWidthTextField from "../../components/TextField/FullWidthTextField";
import FooterV2 from "../../components/FooterV2/FooterV2";
import RadioButton from "../../components/RadioButton/RadioButton";
import BlinkingDots from "../../Animations/BlinkingDots/BlinkingDots";
import { Link, useNavigate } from "react-router-dom";
import PasswordInput from "../../components/PasswordInput/PasswordInput";
import { toast } from "react-toastify";
import {
  loginOtpURL,
  privacypolicyURL,
  resetPassURL,
} from "../../components/helpers/constant-words";
import config from "../../config/config";

import Joi from "joi";
import http from "../../helpers/http";
import { useWindowSize } from "react-use";

const Login = () => {
  const { width } = useWindowSize();
  const [resend, setResend] = useState(false);
  const [loginStep, setLoginStep] = useState("PersonalAccount");
  const navigate = useNavigate();

  const [codes, setCodes] = useState([]);
  const [values, setValues] = useState({
    country_code: "91",
    phone: "",
  });
  const [formError, setFormError] = useState({});
  const joiOptions = config.joiOptions;

  const base_url = config.api_url; //without trailing slash

  const handleChange = (e) => {
    setValues((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
      };
    });
  };
  const handleSelectChange = (value, fieldName) => {
    setValues((prevState) => {
      return {
        ...prevState,
        [fieldName]: value,
      };
    });
  };

  const validate = async (data) => {
    let schemaObj = {
      country_code: Joi.string().trim().required().label("Code"),
      phone: Joi.string().trim().required().label("Mobile No"),
    };

    const schema = Joi.object(schemaObj).options({ allowUnknown: true });

    const { error } = schema.validate(data, joiOptions);

    const errors = {};

    if (error) {
      error.details.map((field) => {
        errors[field.path[0]] = field.message;
        return true;
      });
    }

    return errors ? errors : null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let errors = await validate(values);

    setFormError(errors);
    if (Object.keys(errors).length) {
      return;
    }

    const data = await http.post(base_url + "/personal/login", values);

    if (data) {
      navigate(loginOtpURL, {
        state: values,
      });
    }
  };

  const fetchCodes = async () => {
    const { data } = await http.get(base_url + "/general/countries/codes");

    if (data) {
      setCodes(data);
    }
  };

  useEffect(() => {
    fetchCodes();
  }, []);

  // const accountList = accounts.map((option) => (
  //   <React.Fragment key={option}>
  //     <RadioButton label={option} labelId={option} />
  //   </React.Fragment>
  // ));

  // const OTPMsg = () => (
  //   <div className="otp_box">
  //     <img
  //       width={39}
  //       height={39}
  //       src={checkiconWhite}
  //       className="otp_resend_icon"
  //       loading="lazy"
  //       alt="icon"
  //     />
  //     <p className="title">OTP reshared</p>
  //   </div>
  // );

  const EmailMsg = () => (
    <div className="otp_box">
      <img
        width={39}
        height={39}
        src={checkiconWhite}
        className="otp_resend_icon"
        loading="lazy"
        alt="icon"
      />
      <p className="title">
        New password shared on <br />
        your registered E-mail ID
      </p>
    </div>
  );

  // const resendHandler = () => {
  //   if (resend === false) {
  //     setResend(true);
  //     toast(<OTPMsg />, {
  //       className: "otp_toast",
  //       position: toast.POSITION.TOP_CENTER,
  //       hideProgressBar: true,
  //       closeButton: false,
  //     });
  //   } else {
  //     setResend(false);
  //   }
  // };

  const mailHandler = () => {
    toast(<EmailMsg />, {
      className: "mail_toast",
      position: toast.POSITION.TOP_CENTER,
      hideProgressBar: true,
      closeButton: false,
      autoClose: 1500,
    });
  };

  useEffect(() => {
    const resetButton = setTimeout(() => {
      setResend(false);
    }, 1000);
    return () => clearTimeout(resetButton);
  }, [resend]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <BlinkingDots />
      <main className="user_login_container">

        <section className="login_sec1">
          <div className="my_container">
            <div className="text_container">
              <h2 className="sub_title">Login</h2>
              <h3 className="title">Account Type</h3>
            </div>

            <div className="cateogories_wrapper">
              <div className="cateogory_box">
                <ul
                  className="radio_container"
                  onClick={() => setLoginStep("PersonalAccount")}
                >
                  <RadioButton
                    label="Personal Account"
                    labelId="personal-account"
                    // value="PersonalAccount"
                    labelClass="login_label"
                    checked={loginStep === "PersonalAccount"}
                    // onChange={(e)=> setLoginStep(e.target.value)}
                  />
                </ul>
              </div>
              <div className="cateogory_box">
                <ul
                  className="radio_container"
                  onClick={() => setLoginStep("BusinessAccount")}
                >
                  <RadioButton
                    label="Business Account"
                    labelId="business-account"
                    labelClass="login_label"
                    // value="BusinessAccount"
                    checked={loginStep === "BusinessAccount"}
                    // onClick={(e)=> setLoginStep(e.target.value)}
                  />
                </ul>
              </div>
            </div>
            {loginStep === "PersonalAccount" && (
              <div className="contact_wrapper">
                <form onSubmit={handleSubmit} noValidate>
                  <div className="row field_row">
                    <div className="col-md-12 field_col">
                      <div className="row">
                        <div className="col-4 ps-0">
                          <div className="field_wrapper">
                            <CountryCodeDropdown
                              textLabel="Code"
                              data={codes}
                              onChange={(e, value) => {
                                handleSelectChange(
                                  value.phone_code,
                                  "country_code"
                                );
                              }}
                              defaultValue={{
                                name: "India",
                                iso3: "IND",
                                phone_code: "91",
                              }}
                            />
                          </div>
                        </div>
                        <div className="col-8 pe-0">
                          <div className="field_wrapper">
                            <FullWidthTextField
                              label="Mobile No.*"
                              type="tel"
                              name="phone"
                              value={values.phone}
                              onChange={handleChange}
                            />
                            <p className="error">
                              {formError.country_code || formError.phone}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="terms_text">
                    By continuing, you agree to {width < 600 && <br />}the terms
                    of{" "}
                    <Link
                      to={privacypolicyURL}
                      className="link clr_orange"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Archinza Policy.
                    </Link>
                  </p>
                  <div className="cta_wrapper">
                    <div className="btn_wrapper">
                      <button className="form_btn">
                        Login with OTP
                        <img
                          src={rightarrowwhite}
                          alt="icon"
                          className="icon"
                          loading="lazy"
                        />
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            )}
            {loginStep === "BusinessAccount" && (
              <div className="contact_wrapper">
                <div className="row field_row">
                  <div className="col-md-12 field_col">
                    <div className="field_wrapper">
                      <FullWidthTextField label="Username*" type="text" />
                      {formError?.businesserror && <p className="error"></p>}
                    </div>
                  </div>
                  <div className="col-md-12 field_col">
                    <div className="field_wrapper">
                      <PasswordInput label="Password*" hideIcon={true} />
                      {formError?.businesserror && <p className="error"></p>}
                    </div>
                  </div>
                </div>
                <Link to={resetPassURL} className="reset_notice">
                  Forgot password?
                </Link>
                <p className="terms_text">
                  By continuing, you agree to {width < 600 && <br />}the terms
                  of{" "}
                  <Link
                    to={privacypolicyURL}
                    className="link clr_orange"
                    target="_blank"
                    rel="noreferrer"
                  >
                    Archinza Policy.
                  </Link>
                </p>
                <div className="cta_wrapper">
                  <div className="btn_wrapper">
                    <button
                      className="form_btn"
                      onClick={() => {
                        navigate("/login/otp");
                        window.scrollTo(0, 0);
                      }}
                    >
                      Login with OTP
                      <img
                        src={rightarrowwhite}
                        alt="icon"
                        className="icon"
                        loading="lazy"
                      />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        <FooterV2 />
      </main>
    </>
  );
};
export default Login;
