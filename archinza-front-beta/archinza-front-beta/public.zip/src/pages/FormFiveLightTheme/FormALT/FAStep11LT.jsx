import React, { useEffect } from "react";
import style from "../Form/formfivelighttheme.module.scss";
import LogoutText from "../../../components/LogoutText/LogoutText";
import { rightarrowblack } from "../../../images";
import RadioButton from "../../../components/RadioButton/RadioButton";

const formAMinFeeArr = [
  "0 - 1,00,000 INR",
  "1,00,000 - 5,00,000 INR",
  "5,00,000 - 10,00,000 INR",
  "Above 10,00,000 INR",
];

const FAStep11LT = ({
  nextStep,
  previousStep,
  currentStep,
  totalSteps,
  progressStatus,
}) => {
  const formAMinFeeList = formAMinFeeArr.map((option) => (
    <React.Fragment key={option}>
      <RadioButton
        lightTheme
        extraSpace={true}
        label={option}
        labelId={`PF${option}`}
      />
    </React.Fragment>
  ));

  useEffect(() => {
    progressStatus((currentStep / totalSteps) * 100);
  }, [currentStep, progressStatus, totalSteps]);

  return (
    <>
      <div className={style.text_container}>
        <h1 className={style.title}>Your Current Minimum Project Fee?* </h1>
        <p className={style.description}></p>
        <p className={`${style.top_error_with_space} ${style.error}`}>
          Error message here error message
        </p>
      </div>
      <div className={`${style.steps} ${style.step10}`}>
        <ul className={style.steps_ul}>{formAMinFeeList}</ul>
      </div>

      <div className={style.next_logout}>
        <div className={style.cta_wrapper}>
          <div
            className={style.next_button}
            onClick={() => {
              nextStep(10);
              window.scrollTo(0, 0);
            }}
          >
            <div className={style.text}>Next</div>
            <img
              src={rightarrowblack}
              alt="icon"
              className={style.icon}
              loading="lazy"
            />
          </div>
          <div
            className={style.back_button}
            onClick={() => {
              previousStep(8);
              window.scrollTo(0, 0);
            }}
          >
            Back
          </div>
        </div>
        <LogoutText />
      </div>
    </>
  );
};

export default FAStep11LT;
