import React, { useEffect, useState } from "react";
import style from "../Form/formfivelighttheme.module.scss";
import LogoutText from "../../../components/LogoutText/LogoutText";
import {
  errorFailed,
  errorSuccess,
  formBehance,
  formLinkedin,
  formfb,
  forminsta,
  rightarrowblack,
  websiteicon,
} from "../../../images";
import TextFieldWithIcon from "../../../components/TextFieldWithIcon/TextFieldWithIcon";
import FullWidthTextField from "../../../components/TextField/FullWidthTextField";

const FAStep12LT = ({
  nextStep,
  previousStep,
  currentStep,
  totalSteps,
  progressStatus,
}) => {
  const [gstValid, setGstValid] = useState(true);

  useEffect(() => {
    progressStatus((currentStep / totalSteps) * 100);
  }, [currentStep, progressStatus, totalSteps]);

  return (
    <>
      <div className={style.text_container}>
        <h1 className={style.title}>
          Be found by clients,{" "}
          <span className={style.coloured_text}>led by AI!</span>
        </h1>
        <p className={style.description}>One mandatory</p>
      </div>
      <div className={`${style.steps} ${style.reduceSpace}`}>
        <div className={`row ${style.owner_row}`}>
          <div className="col-md-6">
            <div className={style.field_wrapper}>
              <TextFieldWithIcon
                lightTheme
                label="Website"
                icon={websiteicon}
              />
              <p className={style.error}>Error message here error message</p>
            </div>
          </div>
          <div className="col-md-6">
            <div className={style.field_wrapper}>
              <TextFieldWithIcon
                lightTheme
                label="Instagram"
                icon={forminsta}
              />

              <p className={style.error}>Error message here error message</p>
            </div>
          </div>
          <div className="col-md-6">
            <div className={style.field_wrapper}>
              <TextFieldWithIcon
                lightTheme
                label="Linkedin"
                icon={formLinkedin}
              />

              <p className={style.error}>Error message here error message</p>
            </div>
          </div>
          <div className="col-md-6">
            <div className={style.field_wrapper}>
              <FullWidthTextField lightTheme label="Address/ google location" />

              <p className={style.error}>Error message here error message</p>
            </div>
          </div>
          <div className="col-md-6">
            <div className={style.field_wrapper}>
              <div className={style.input_wrapper}>
                <FullWidthTextField
                  lightTheme
                  type="text"
                  label="GST number"
                  onClick={() => setGstValid((prev) => !prev)}
                />
                {!gstValid && (
                  <img
                    className={style.val_icon}
                    src={errorFailed}
                    alt="failed"
                  />
                )}
                {gstValid && (
                  <img
                    className={style.val_icon}
                    src={errorSuccess}
                    alt="success"
                  />
                )}
              </div>
              <p className={`${style.error_text}`}>
                GST number should be at least 15 characters
              </p>
              <p className={style.error}>Error messsage here error messsage</p>
            </div>
          </div>
        </div>
      </div>

      <div className={style.next_logout}>
        <div className={style.cta_wrapper}>
          <div
            className={style.next_button}
            onClick={() => {
              nextStep(10);
              window.scrollTo(0, 0);
            }}
          >
            <div className={style.text}>Next</div>
            <img
              src={rightarrowblack}
              alt="icon"
              className={style.icon}
              loading="lazy"
            />
          </div>
          <div
            className={style.back_button}
            onClick={() => {
              previousStep(8);
              window.scrollTo(0, 0);
            }}
          >
            Back
          </div>
        </div>
        <LogoutText />
      </div>
    </>
  );
};

export default FAStep12LT;
