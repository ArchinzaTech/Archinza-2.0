import React, { useEffect } from "react";
import style from "../Form/formfivelighttheme.module.scss";
import LogoutText from "../../../components/LogoutText/LogoutText";
import { rightarrowblack } from "../../../images";
import CheckboxButton from "../../../components/CheckboxButton/CheckboxButton";
import AutoCompleteOthers from "../../../components/AutoCompleteOthers/AutoCompleteOthers";

const formASupportArr = [
  { label: "3d renders" },
  { label: "bill checking" },
  { label: "boq" },
  { label: "estimation" },
  { label: "project management" },
  { label: "site survey" },
  { label: "site measurement" },
  { label: "Site Visits" },
  { label: "Sampling" },
  { label: "Site supervision" },
  { label: "Shop Drawing" },
  { label: "working drawings" },
];
const newFormASupportArr = ["newly added"];

const FAStep02LT = ({
  nextStep,
  currentStep,
  totalSteps,
  progressStatus,
  previousStep,
}) => {
  const newFormASupportList = newFormASupportArr.map((option) => (
    <React.Fragment key={option}>
      <CheckboxButton
        lightTheme
        isChecked={true}
        label={option}
        labelId={option}
      />
    </React.Fragment>
  ));

  useEffect(() => {
    progressStatus((currentStep / totalSteps) * 100);
  }, [currentStep, progressStatus, totalSteps]);

  return (
    <>
      <div className={style.text_container}>
        <h1 className={style.title}>
          What support does the business/firm provide in addition to Design
          Consulting?*
        </h1>
        <p className={style.description}>Popular Tags (Choose As Many)</p>
        <p className={`${style.rstep02Error} ${style.error}`}>
          Error message here error message
        </p>
      </div>
      <div className={`${style.steps} ${style.fastep04}`}>
        <div className={`${style.add_more_wrap} ${style.add_more_v2}`}>
          <div className={style.field_wrapper}>
            <AutoCompleteOthers
              lightTheme
              textLabel="Choose As Many"
              data={formASupportArr}
            />
          </div>
        </div>
        <ul className={`${style.steps_ul} ${style.new_list}`}>
          {newFormASupportList}
        </ul>
      </div>

      <div className={style.next_logout}>
        <div className={style.cta_wrapper}>
          <div
            className={style.next_button}
            onClick={() => {
              nextStep();
              window.scrollTo(0, 0);
            }}
          >
            <div className={style.text}>Next</div>
            <img
              src={rightarrowblack}
              alt="icon"
              className={style.icon}
              loading="lazy"
            />
          </div>
          <div
            className={style.back_button}
            onClick={() => {
              previousStep();
              window.scrollTo(0, 0);
            }}
          >
            Back
          </div>
        </div>
        <LogoutText />
      </div>
    </>
  );
};

export default FAStep02LT;
