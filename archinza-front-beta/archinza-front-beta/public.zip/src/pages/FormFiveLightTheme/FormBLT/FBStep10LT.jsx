import React, { useEffect } from "react";
import style from "../Form/formfivelighttheme.module.scss";
import LogoutText from "../../../components/LogoutText/LogoutText";
import { rightarrowblack } from "../../../images";
import AutoCompleteOthers from "../../../components/AutoCompleteOthers/AutoCompleteOthers";
import CheckboxButton from "../../../components/CheckboxButton/CheckboxButton";

const formBPreferencesArr = [
  { label: "All" },
  { label: "Fresh" },
  { label: "Consutruction" },
  { label: "Complete Renovation" },
  { label: "Partial Renovation" },
  { label: "Repair" },
  { label: "Audit" },
  { label: "Furniture Design" },
  { label: "Project management" },
];

const newOptionsArr = ["newly added"];

const FBStep10LT = ({
  nextStep,
  previousStep,
  currentStep,
  totalSteps,
  progressStatus,
}) => {
  const newAdditionList = newOptionsArr.map((option) => (
    <React.Fragment key={option}>
      <CheckboxButton
        lightTheme
        isChecked={true}
        label={option}
        labelId={option}
      />
    </React.Fragment>
  ));

  useEffect(() => {
    progressStatus((currentStep / totalSteps) * 100);
  }, [currentStep, progressStatus, totalSteps]);

  return (
    <>
      <div className={style.text_container}>
        <h1 className={style.title}>Preference of Project Scope</h1>
        <p className={style.description}>Popular Tags (Choose As Many)</p>
        <p className={`${style.rstep02Error} ${style.error}`}>
          Error message here error message
        </p>
      </div>
      <div className={`${style.steps} ${style.fastep04}`}>
        <div className={`${style.add_more_wrap} ${style.add_more_v2}`}>
          <div className={style.field_wrapper}>
            <AutoCompleteOthers
              lightTheme
              textLabel="Choose As Many"
              data={formBPreferencesArr}
            />
          </div>
        </div>
        <ul className={`${style.steps_ul} ${style.new_list}`}>
          {newAdditionList}
        </ul>
      </div>

      <div className={style.next_logout}>
        <div className={style.cta_wrapper}>
          <div
            className={style.next_button}
            onClick={() => {
              nextStep(10);
              window.scrollTo(0, 0);
            }}
          >
            <div className={style.text}>Next</div>
            <img
              src={rightarrowblack}
              alt="icon"
              className={style.icon}
              loading="lazy"
            />
          </div>
          <div
            className={style.back_button}
            onClick={() => {
              previousStep(8);
              window.scrollTo(0, 0);
            }}
          >
            Back
          </div>
        </div>
        <LogoutText />
      </div>
    </>
  );
};

export default FBStep10LT;
