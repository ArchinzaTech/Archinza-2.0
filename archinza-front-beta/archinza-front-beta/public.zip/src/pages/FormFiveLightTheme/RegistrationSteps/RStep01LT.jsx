import React, { useEffect, useState } from "react";
import style from "../Form/formfivelighttheme.module.scss";
import LogoutText from "../../../components/LogoutText/LogoutText";
import { blackDeleteicon, plusicon, rightarrowblack } from "../../../images";
import { countries } from "../../../db/dataTypesData";
import FullWidthTextField from "../../../components/TextField/FullWidthTextField";
import AutoCompleteField from "../../../components/AutoCompleteField/AutoCompleteField";
import CountryCodeDropdown from "../../../components/CountryCodeDropdown/CountryCodeDropdown";

const RStep01LT = ({ nextStep, currentStep, totalSteps, progressStatus }) => {
  const [secondRow, setSecondRow] = useState(false);
  useEffect(() => {
    progressStatus((currentStep / totalSteps) * 100);
  }, [currentStep, progressStatus, totalSteps]);

  return (
    <>
      {/* <div className={style.text_container}>
        <h1 className={style.title}>Tell us about your business</h1>
        <p className={style.description}></p>
      </div> */}
      <div className={`${style.steps} ${style.rstep1}`}>
        {/* <div className={style.brand_box}>
          <div className={style.business_details}>
            <div className={`row`}>
              <div className={`col-md-6 ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <FullWidthTextField
                    lightTheme
                    key="Name of the Contact person*"
                    label="Name of the Contact person*"
                  />
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
              </div>
              <div className={`col-md-6 ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <div className="row">
                    <div className="col-4 col-sm-4 col-md-4 ps-0">
                      <div className={style.country_code}>
                        <CountryCodeDropdown
                          lightTheme
                          textLabel="Code"
                        />
                        <p className={style.error}>
                          Error messsage here error messsage
                        </p>
                      </div>
                    </div>
                    <div className="col-8 col-sm-8 col-md-8 pe-0">
                      <div className={style.country_code}>
                        <FullWidthTextField
                          lightTheme
                          key="number"
                          label="Phone*"
                          type="number"
                        />
                        <p className={style.error}>
                          Error messsage here error messsage
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={`col-md-6 ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <FullWidthTextField
                    lightTheme
                    key="WhatsApp number*"
                    label="WhatsApp number*"
                  />
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
                <div className={style.checkbox_wrapper}>
                  <label className={style.checkbox_label} htmlFor="sameas">
                    <input
                      type="checkbox"
                      className={style.check_box}
                      id="sameas"
                    />
                    Same as phone number
                  </label>
                </div>
              </div>
              <div className={`col-md-6  ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <AutoCompleteField
                    lightTheme
                    textLabel="Country*"
                    data={countries}
                  />
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
              </div>
              <div className={`col-md-6  ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <AutoCompleteField
                    lightTheme
                    textLabel="City*"
                    data={countries}
                  />
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
              </div>
              <div className={`col-md-6  ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <FullWidthTextField
                    lightTheme
                    type="number"
                    label="Pincode*"
                  />
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
              </div>
              <div className={`col-md-6  ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <FullWidthTextField
                    lightTheme
                    type="text"
                    label="Account Username*"
                  />
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
              </div>
              <div className={`col-md-6  ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <FullWidthTextField
                    lightTheme
                    type="text"
                    label="Account Password*"
                  />
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div> */}
        <div className={style.personal_box}>
          <div className={style.personal_details}>
            <div className={style.text_container}>
              <h1 className={style.title}>Owners Contact Details</h1>
              <p className={style.description}></p>
            </div>
            <div className={`row`}>
              <div className={`col-md-6 ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <FullWidthTextField
                    lightTheme
                    key="Name of the Owner*"
                    label="Name of the Owner*"
                  />
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
              </div>
              <div className={`col-md-6 ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <FullWidthTextField
                    lightTheme
                    key="Email ID"
                    label="Email ID*"
                  />{" "}
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
              </div>
              <div className={`col-md-6 ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <div className="row">
                    <div className="col-4 col-sm-4 col-md-4 ps-0">
                      <div className={style.country_code}>
                        <CountryCodeDropdown lightTheme textLabel="Code" />
                        <p className={style.error}>
                          Error messsage here error messsage
                        </p>
                      </div>
                    </div>
                    <div className="col-8 col-sm-8 col-md-8 pe-0">
                      <div className={style.country_code}>
                        <FullWidthTextField
                          lightTheme
                          key="number"
                          label="Phone*"
                          type="number"
                        />
                        <p className={style.error}>
                          Error messsage here error messsage
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={`col-md-6 ${style.rstep01_col}`}>
                <div className={style.field_wrapper}>
                  <FullWidthTextField
                    lightTheme
                    key="WhatsApp number*"
                    label="WhatsApp number*"
                  />
                  <p className={style.error}>
                    Error messsage here error messsage
                  </p>
                </div>
                <div className={style.checkbox_wrapper}>
                  <label className={style.checkbox_label} htmlFor="sameas">
                    <input
                      type="checkbox"
                      className={style.check_box}
                      id="sameas"
                    />
                    Same as phone number
                  </label>
                </div>
              </div>
            </div>
            <div className={style.add_category}>
              <div className={style.dashed_line}></div>
              <div
                className={style.add_flex}
                onClick={() => setSecondRow(true)}
              >
                <img src={plusicon} alt="icon" className={style.icon} />
                <div className={style.title}>Add more names</div>
              </div>
              <div className={style.dashed_line}></div>
            </div>
            {secondRow === true && (
              <div className={`row ${style.owner_row}`}>
                <div className={`col-md-6 ${style.rstep01_col}`}>
                  <div className={style.field_wrapper}>
                    <FullWidthTextField
                      lightTheme
                      key="Name of the Owner*"
                      label="Name of the Owner*"
                    />
                    <p className={style.error}>
                      Error messsage here error messsage
                    </p>
                  </div>
                </div>
                <div className={`col-md-6 ${style.rstep01_col}`}>
                  <div className={style.field_wrapper}>
                    <FullWidthTextField
                      lightTheme
                      key="Email ID"
                      label="Email ID*"
                    />{" "}
                    <p className={style.error}>
                      Error messsage here error messsage
                    </p>
                  </div>
                </div>
                <div className={`col-md-6 ${style.rstep01_col}`}>
                  <div className={style.field_wrapper}>
                    <div className="row">
                      <div className="col-4 col-sm-4 col-md-4 ps-0">
                        <div className={style.country_code}>
                          <CountryCodeDropdown lightTheme textLabel="Code" />
                          <p className={style.error}>
                            Error messsage here error messsage
                          </p>
                        </div>
                      </div>
                      <div className="col-8 col-sm-8 col-md-8 pe-0">
                        <div className={style.country_code}>
                          <FullWidthTextField
                            lightTheme
                            key="number"
                            label="Phone*"
                            type="number"
                          />
                          <p className={style.error}>
                            Error messsage here error messsage
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={`col-md-6 ${style.rstep01_col}`}>
                  <div className={style.field_wrapper}>
                    <FullWidthTextField
                      lightTheme
                      key="WhatsApp number*"
                      label="WhatsApp number*"
                    />
                    <p className={style.error}>
                      Error messsage here error messsage
                    </p>
                  </div>
                  <div className={style.checkbox_wrapper}>
                    <label className={style.checkbox_label} htmlFor="sameas">
                      <input
                        type="checkbox"
                        className={style.check_box}
                        id="sameas"
                      />
                      Same as phone number
                    </label>
                  </div>
                  <div className={style.add_delete_icon}>
                    <img
                      src={plusicon}
                      alt="icon"
                      className={style.plusicon}
                      loading="lazy"
                      onClick={() => setSecondRow(true)}
                    />
                    <img
                      src={blackDeleteicon}
                      alt="icon"
                      className={style.deleteicon}
                      loading="lazy"
                      style={{ visibility: "visible" }}
                      onClick={() => {
                        setSecondRow(false);
                        window.scroll(0, 0);
                      }}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className={style.next_logout}>
        <div className={style.cta_wrapper}>
          <div
            className={style.next_button}
            onClick={() => {
              nextStep();
              window.scrollTo(0, 0);
            }}
          >
            <div className={style.text}>Next</div>
            <img
              src={rightarrowblack}
              alt="icon"
              className={style.icon}
              loading="lazy"
            />
          </div>
        </div>
        <LogoutText />
      </div>
    </>
  );
};

export default RStep01LT;
