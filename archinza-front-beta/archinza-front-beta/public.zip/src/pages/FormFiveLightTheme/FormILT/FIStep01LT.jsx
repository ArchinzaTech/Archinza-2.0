import React, { useEffect } from "react";
import style from "../Form/formfivelighttheme.module.scss";
import LogoutText from "../../../components/LogoutText/LogoutText";
import { rightarrowblack } from "../../../images";
import CheckboxButton from "../../../components/CheckboxButton/CheckboxButton";
import AutoCompleteOthers from "../../../components/AutoCompleteOthers/AutoCompleteOthers";

const formIServicesArr = [
  { label: "3D Modeling" },
  { label: "3D Visualisation/Rendering" },
  { label: "Accessibility Design" },
  { label: "Acoustic Consulting" },
  { label: "Acoustic Design" },
  { label: "ADA Compliance Consulting" },
  { label: "Architectural Design" },
  { label: "Art Consultation" },
  { label: "Audiovisual system design" },
  { label: "Augmented Reality (AR) Design" },
  { label: "Barrier-Free Design" },
  { label: "Bathroom Design" },
  { label: "Biophilic Design" },
  { label: "Building Code Analysis" },
  { label: "Building Code Consulting" },
  { label: "Building Information Modeling (BIM)" },
  { label: "Building Performance Analysis" },
  { label: "Building permits and approvals" },
  { label: "Building renovation/restoration" },
  { label: "CAD Drafting" },
  { label: "Ceiling design" },
  { label: "Civil Engineering" },
  { label: "Closet and storage design" },
  { label: "Color Consulting" },
  { label: "Color Consulting" },
  { label: "Commercial Design" },
  { label: "Commissioning Services" },
  { label: "Communications Systems Design" },
  { label: "Community Planning" },
  { label: "Conceptual design" },
  { label: "Construction cost estimating" },
  { label: "Construction Documents" },
  { label: "Construction Management" },
  { label: "Corporate Headquarters Design" },
  { label: "Cost Estimation" },
  { label: "Cultural facility design" },
  { label: "Custom Furniture Design" },
  { label: "Custom millwork design" },
  { label: "Design development" },
  { label: "Ecological Design" },
  { label: "Educational facility design" },
  { label: "Electrical Design" },
  { label: "Electrical system design" },
  { label: "Energy Audits" },
  { label: "Energy efficiency analysis" },
  { label: "Energy Modeling" },
  { label: "Entertainment venue design" },
  { label: "Environmental Consulting" },
  { label: "Environmental Impact Assessment" },
  { label: "Exhibit Design" },
  { label: "Exhibition and Museum design" },
  { label: "Exhibition Design" },
  { label: "Exterior Design" },
  { label: "Facade Design" },
  { label: "Façade Engineering" },
  { label: "Feasibility Studies" },
  { label: "Feng Shui Consultation" },
  { label: "Fire Protection Engineering" },
  { label: "Fire safety consulting" },
  { label: "Fixture selection and procurement" },
  { label: "Flooring design and selection" },
  { label: "Foundation design" },
  { label: "Furniture Design" },
  { label: "Furniture selection and procurement" },
  { label: "Graphics and branding design" },
  { label: "Green Building Certification" },
  { label: "Green Building Design" },
  { label: "Hardscape design" },
  { label: "Healthcare facility design" },
  { label: "Historic preservation consulting" },
  { label: "Home Automation Design" },
  { label: "Hospitality design" },
  { label: "HVAC Design (Heating, Ventilation, and Air Conditioning)" },
  { label: "Indoor air quality analysis" },
  { label: "Industrial facility design" },
  { label: "Infrastructure Planning" },
  { label: "Interior Design" },
  { label: "Interior styling" },
  { label: "Irrigation system design" },
  { label: "Kitchen and Bath Design" },
  { label: "Kitchen Design" },
  { label: "Landscape Architecture" },
  { label: "Landscape Design" },
  { label: "LEED certification consulting" },
  { label: "Lighting Design" },
  { label: "Market analysis" },
  { label: "Master Planning" },
  { label: "Material sourcing and specification" },
  { label: "Materials Consultation" },
  { label: "mechanical design" },
  { label: "MEP Engineering (Mechanical, Electrical, Plumbing)" },
  { label: "Mixed-use development planning" },
  { label: "Noise Control Consulting" },
  { label: "Office space planning" },
  { label: "Outdoor lighting design" },
  { label: "Passive design strategies" },
  { label: "Permit expediting" },
  { label: "Photorealistic Rendering" },
  { label: "Plumbing Design" },
  { label: "Plumbing supply & Drainage design consultancy" },
  { label: "Plumbing system design" },
  { label: "Product Design" },
  { label: "Project Management" },
  { label: "Public Space Design" },
  { label: "Real estate development consulting" },
  { label: "Religious facility design" },
  { label: "Renewable Energy Consulting" },
  { label: "Residential design" },
  { label: "Restaurant and café design" },
  { label: "Retail design" },
  { label: "Retail store design" },
  { label: "Risk Assessment" },
  { label: "Roof design" },
  { label: "Security Consulting" },
  { label: "Security system design" },
  { label: "Signage and Wayfinding Design" },
  { label: "Site analysis" },
  { label: "Site development planning" },
  { label: "Site grading and drainage planning" },
  { label: "Site Planning" },
  { label: "Site selection analysis" },
  { label: "Smart Building Systems Design" },
  { label: "Softscape design" },
  { label: "Solar Design" },
  { label: "Space Planning" },
  { label: "Sports facility design" },
  { label: "Stormwater management" },
  { label: "Structural Engineering" },
  { label: "Structural retrofitting" },
  { label: "structure design" },
  { label: "Subdivision planning" },
  { label: "Sustainability Consulting" },
  { label: "Sustainable Design" },
  { label: "Sustainable materials consulting" },
  { label: "Systems Integration" },
  { label: "Telecommunications Design" },
  { label: "Tenant improvement design" },
  { label: "Textile Design" },
  { label: "Textile selection and coordination" },
  { label: "Thermal Comfort Consultation" },
  { label: "Traffic Engineering" },
  { label: "Transit-oriented development planning" },
  { label: "Universal Design" },
  { label: "Urban Design" },
  { label: "Urban planning" },
  { label: "Urban revitalization planning" },
  { label: "Vastu Consulting" },
  { label: "Vastu Shastra Consultation" },
  { label: "Virtual Reality (VR) Design" },
  { label: "Visualization and Rendering" },
  { label: "Wall covering design and selection" },
  { label: "Waste Management Consultation" },
  { label: "Water Efficiency Consulting" },
  { label: "Water feature design" },
  { label: "Wayfinding Design" },
  { label: "Wayfinding Systems" },
  { label: "Window treatment design" },
  { label: "Zero Net Energy Design" },
  { label: "Zoning and entitlement assistance" },
  { label: "Interior Architecture" },
  { label: "Signage Design" },
];

const newOptionsArr = ["newly added"];

const FIStep01LT = ({
  nextStep,
  currentStep,
  totalSteps,
  progressStatus,
  previousStep,
}) => {
  const newAdditionList = newOptionsArr.map((option) => (
    <React.Fragment key={option}>
      <CheckboxButton
        lightTheme
        isChecked={true}
        label={option}
        labelId={option}
      />
    </React.Fragment>
  ));

  useEffect(() => {
    progressStatus((currentStep / totalSteps) * 100);
  }, [currentStep, progressStatus, totalSteps]);

  return (
    <>
      <div className={style.text_container}>
        <h1 className={style.title}>Name of your business*</h1>
        <p className={style.description}>Popular Tags (Choose As Many)</p>
        <p className={`${style.rstep02Error} ${style.error}`}>
          Error message here error message
        </p>
      </div>
      <div className={`${style.steps} ${style.fastep04}`}>
        <div className={`${style.add_more_wrap} ${style.add_more_v2}`}>
          <div className={style.field_wrapper}>
            <AutoCompleteOthers
              lightTheme
              textLabel="Choose As Many"
              data={formIServicesArr}
            />
          </div>
        </div>
        <ul className={`${style.steps_ul} ${style.new_list}`}>
          {newAdditionList}
        </ul>
      </div>

      <div className={style.next_logout}>
        <div className={style.cta_wrapper}>
          <div
            className={style.next_button}
            onClick={() => {
              nextStep();
              window.scrollTo(0, 0);
            }}
          >
            <div className={style.text}>Next</div>
            <img
              src={rightarrowblack}
              alt="icon"
              className={style.icon}
              loading="lazy"
            />
          </div>
          <div
            className={style.back_button}
            onClick={() => {
              previousStep();
              window.scrollTo(0, 0);
            }}
          >
            Back
          </div>
        </div>
        <LogoutText />
      </div>
    </>
  );
};

export default FIStep01LT;
