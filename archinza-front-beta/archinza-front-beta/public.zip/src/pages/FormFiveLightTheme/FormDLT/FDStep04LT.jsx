import React, { useEffect } from "react";
import style from "../Form/formfivelighttheme.module.scss";
import LogoutText from "../../../components/LogoutText/LogoutText";
import { rightarrowblack } from "../../../images";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import dayjs from "dayjs";
import { useWindowSize } from "react-use";

const FDStep04LT = ({
  previousStep,
  nextStep,
  currentStep,
  totalSteps,
  progressStatus,
  lightTheme,
}) => {
  const { width } = useWindowSize();
  const startDate = dayjs("1974-01-01T00:00:00.000");

  useEffect(() => {
    progressStatus((currentStep / totalSteps) * 100);
  }, [currentStep, progressStatus, totalSteps]);

  return (
    <>
      <div className={style.text_container}>
        <h1 className={style.title}>Year of establishment*</h1>
        <p className={style.description}></p>
        <p className={`${style.rstep02Error} ${style.error}`}>
          Error message here error message
        </p>
      </div>
      <div className={`${style.steps} ${style.fastep04}`}>
        <div className={`${style.add_more_wrap} ${style.add_more_v2}`}>
          <div className={style.field_wrapper}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DemoContainer components={["DatePicker", "DatePicker"]}>
                <DatePicker
                  label={"Year"}
                  openTo="year"
                  views={["year"]}
                  minDate={startDate}
                  // maxDate={endOfQ12022}
                  disableFuture
                  className="year_date_picker"
                  sx={{
                    width: "100%",
                    minWidth: "100%",
                    background: lightTheme ? "fff" : "111",
                    "& .MuiOutlinedInput-root": {
                      borderRadius: width > 768 ? "10px" : "10px",
                    },
                    "& label": {
                      lineHeight: width > 768 ? "2em" : "1.5em",
                    },
                    "& label.Mui-focused": {
                      color: lightTheme ? "#111" : "fff",
                    },
                    "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                      {
                        borderRadius: width > 768 ? "10px" : "10px",
                        border: "1px solid #707070",
                      },
                    "& .MuiOutlinedInput-root .Mui-focused .MuiOutlinedInput-notchedOutline":
                      {
                        border: "1px solid #707070",
                      },
                    "&.Mui-focused .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
                      {
                        borderColor: lightTheme ? "#111" : "fff",
                      },
                    "& .MuiSvgIcon-root ": {
                      fill: "#f77b00 !important",
                    },
                  }}
                />
              </DemoContainer>
            </LocalizationProvider>
          </div>
        </div>
      </div>

      <div className={style.next_logout}>
        <div className={style.cta_wrapper}>
          <div
            className={style.next_button}
            onClick={() => {
              nextStep(4);
              window.scrollTo(0, 0);
            }}
          >
            <div className={style.text}>Next</div>
            <img
              src={rightarrowblack}
              alt="icon"
              className={style.icon}
              loading="lazy"
            />
          </div>
          <div
            className={style.back_button}
            onClick={() => {
              previousStep(2);
              window.scrollTo(0, 0);
            }}
          >
            Back
          </div>
        </div>
        <LogoutText />
      </div>
    </>
  );
};

export default FDStep04LT;
