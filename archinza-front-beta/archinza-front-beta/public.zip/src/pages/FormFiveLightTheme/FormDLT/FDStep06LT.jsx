import React, { useEffect } from "react";
import style from "../Form/formfivelighttheme.module.scss";
import LogoutText from "../../../components/LogoutText/LogoutText";
import { rightarrowblack } from "../../../images";
import CheckboxButton from "../../../components/CheckboxButton/CheckboxButton";
import AutoCompleteField from "../../../components/AutoCompleteField/AutoCompleteField";

const formDProjectTypologyArr = [
  { label: "ALL" },
  { label: "Adaptive Reuse" },
  { label: "Commercial" },
  { label: "Conservation" },
  { label: "Cultural" },
  { label: "Educational" },
  { label: "Environmental" },
  { label: "Healthcare" },
  { label: "Historical Restoration" },
  { label: "Hospitality" },
  { label: "Industrial" },
  { label: "Institutional" },
  { label: "Interior" },
  { label: "Landscape" },
  { label: "Mixed-Use" },
  { label: "Public Spaces" },
  { label: "Recreational" },
  { label: "Renovation" },
  { label: "Residential" },
  { label: "Retail" },
  { label: "Socially Responsive Design" },
  { label: "Sustainable" },
  { label: "Technology-Centric" },
  { label: "Urban Planning" },
  { label: "Workspace" },
  { label: "Exhibition Spaces" },
  { label: "Historical" },
  { label: "Vintage" },
];

const newTypologyArr = ["newly added"];

const FDStep06LT = ({
  nextStep,
  previousStep,
  currentStep,
  totalSteps,
  progressStatus,
}) => {
  const newTypologyList = newTypologyArr.map((option) => (
    <React.Fragment key={option}>
      <CheckboxButton
        lightTheme
        isChecked={true}
        label={option}
        labelId={option}
      />
    </React.Fragment>
  ));

  useEffect(() => {
    progressStatus((currentStep / totalSteps) * 100);
  }, [currentStep, progressStatus, totalSteps]);

  return (
    <>
      <div className={style.text_container}>
        <h1 className={style.title}>Project Typology*</h1>
        <p className={style.description}></p>
        <p className={`${style.top_error_with_space} ${style.error}`}>
          Error message here error message
        </p>
      </div>
      <div className={`${style.steps} ${style.fastep04}`}>
        <div className={`${style.add_more_wrap} ${style.add_more_v2}`}>
          <div className={style.field_wrapper}>
            <AutoCompleteField
              lightTheme
              textLabel="Choose As Many"
              data={formDProjectTypologyArr}
            />
          </div>
        </div>
        <ul className={`${style.steps_ul} ${style.new_list}`}>
          {newTypologyList}
        </ul>
      </div>

      <div className={style.next_logout}>
        <div className={style.cta_wrapper}>
          <div
            className={style.next_button}
            onClick={() => {
              nextStep(7);
              window.scrollTo(0, 0);
            }}
          >
            <div className={style.text}>Next</div>
            <img
              src={rightarrowblack}
              alt="icon"
              className={style.icon}
              loading="lazy"
            />
          </div>
          <div
            className={style.back_button}
            onClick={() => {
              previousStep(5);
              window.scrollTo(0, 0);
            }}
          >
            Back
          </div>
        </div>
        <LogoutText />
      </div>
    </>
  );
};

export default FDStep06LT;
