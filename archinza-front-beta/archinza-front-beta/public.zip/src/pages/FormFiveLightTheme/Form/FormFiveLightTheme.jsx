import React, { useEffect, useState } from "react";
import style from "./formfivelighttheme.module.scss";
import StoreSettings from "../../../components/StoreSettings/StoreSettings";
import StepWizard from "react-step-wizard";
// Form 5 imports
// Form 5 imports
import RStep01LT from "../RegistrationSteps/RStep01LT";
import RStep02LT from "../RegistrationSteps/RStep02LT";
// Form 5 A imports
// Form 5 A imports
import FAStep01LT from "../FormALT/FAStep01LT";
import FAStep04LT from "../FormALT/FAStep04LT";
import FAStep05LT from "../FormALT/FAStep05LT";
import FAStep06LT from "../FormALT/FAStep06LT";
import FAStep07LT from "../FormALT/FAStep07LT";
import FAStep08LT from "../FormALT/FAStep08LT";
import FAStep09LT from "../FormALT/FAStep09LT";
import FAStep10LT from "../FormALT/FAStep10LT";
import FAStep11LT from "../FormALT/FAStep11LT";
import FAStep12LT from "../FormALT/FAStep12LT";
// Form 5 B imports
// Form 5 B imports
import FBStep01LT from "../FormBLT/FBStep01LT";
import FBStep02LT from "../FormBLT/FBStep02LT";
import FBStep03LT from "../FormBLT/FBStep03LT";
import FBStep04LT from "../FormBLT/FBStep04LT";
import FBStep05LT from "../FormBLT/FBStep05LT";
import FBStep06LT from "../FormBLT/FBStep06LT";
import FBStep07LT from "../FormBLT/FBStep07LT";
import FBStep08LT from "../FormBLT/FBStep08LT";
import FBStep09LT from "../FormBLT/FBStep09LT";
import FBStep10LT from "../FormBLT/FBStep10LT";
import FBStep11LT from "../FormBLT/FBStep11LT";
import FBStep12LT from "../FormBLT/FBStep12LT";
import FBStep13LT from "../FormBLT/FBStep13LT";
import FBStep14LT from "../FormBLT/FBStep14LT";
// Form 5 C imports
// Form 5 C imports
import FCStep01LT from "../FormCLT/FCStep01LT";
import FCStep02LT from "../FormCLT/FCStep02LT";
import FCStep03LT from "../FormCLT/FCStep03LT";
import FCStep04LT from "../FormCLT/FCStep04LT";
import FCStep05LT from "../FormCLT/FCStep05LT";
import FCStep06LT from "../FormCLT/FCStep06LT";
import FCStep07LT from "../FormCLT/FCStep07LT";
import FCStep08LT from "../FormCLT/FCStep08LT";
import FCStep09LT from "../FormCLT/FCStep09LT";
// Form 5 D imports
// Form 5 D imports
import FDStep01LT from "../FormDLT/FDStep01LT";
import FDStep02LT from "../FormDLT/FDStep02LT";
import FDStep03LT from "../FormDLT/FDStep03LT";
import FDStep04LT from "../FormDLT/FDStep04LT";
import FDStep05LT from "../FormDLT/FDStep05LT";
import FDStep06LT from "../FormDLT/FDStep06LT";
import FDStep07LT from "../FormDLT/FDStep07LT";
import FDStep08LT from "../FormDLT/FDStep08LT";
import FCStep10LT from "../FormCLT/FCStep10LT";
import FDStep09LT from "../FormDLT/FDStep09LT";
import LightThemeBackground from "../../../Animations/LightThemeBackground/LightThemeBackground";
import BorderLinearProgressLightTheme from "../../../components/ProgressBarLightTheme/ProgressBarLightTheme";
import FooterV2 from "../../../components/FooterV2/FooterV2";
import FAStep02LT from "../FormALT/FAStep02LT";
import FAStep03LT from "../FormALT/FAStep03LT";
import FCStep11LT from "../FormCLT/FCStep11LT";
import FEStep01LT from "../FormELT/FEStep01LT";
import FEStep02LT from "../FormELT/FEStep02LT";
import FEStep03LT from "../FormELT/FEStep03LT";
import FEStep04LT from "../FormELT/FEStep04LT";
import FEStep05LT from "../FormELT/FEStep05LT";
import FEStep06LT from "../FormELT/FEStep06LT";
import FFStep01LT from "../FormFLT/FFStep01LT";
import FFStep02LT from "../FormFLT/FFStep02LT";
import FFStep03LT from "../FormFLT/FFStep03LT";
import FFStep04LT from "../FormFLT/FFStep04LT";
import FFStep05LT from "../FormFLT/FFStep05LT";
import FGStep01LT from "../FormGLT/FGStep01LT";
import FGStep02LT from "../FormGLT/FGStep02LT";
import FGStep03LT from "../FormGLT/FGStep03LT";
import FHStep01LT from "../FormHLT/FHStep01LT";
import FHStep02LT from "../FormHLT/FHStep02LT";
import FHStep04LT from "../FormHLT/FHStep04LT";
import FHStep03LT from "../FormHLT/FHStep03LT";
import FIStep01LT from "../FormILT/FIStep01LT";
import FIStep02LT from "../FormILT/FIStep02LT";
import FIStep03LT from "../FormILT/FIStep03LT";
import FJStep01LT from "../FormJLT/FJStep01LT";
import FJStep02LT from "../FormJLT/FJStep02LT";
import FJStep03LT from "../FormJLT/FJStep03LT";
import FJStep04LT from "../FormJLT/FJStep04LT";

const FormFiveLightTheme = () => {
  const [progress, setProgress] = useState(0);
  const [formStep] = useState(1);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      {/* <BlinkingDots /> */}
      <LightThemeBackground />
      <section className={style.formfive_sec1_lt}>
        <div className={style.formfive_form_wrap}>
          <div className="my_container">
            <div className={style.progress_wrapper}>
              <BorderLinearProgressLightTheme
                variant="determinate"
                value={progress}
              />
            </div>
            <div className={style.steps_wrapper}>
              <StepWizard
                initialStep={formStep}
                transitions={{
                  enterRight: "formChangeAnimation",
                  enterLeft: "formChangeAnimation",
                  intro: "formChangeAnimation",
                }}
              >
                <RStep01LT progressStatus={setProgress} />
                <RStep02LT progressStatus={setProgress} />
                {/* FORM A steps */}
                {/* FORM A steps */}
                {/* FORM A steps */}
                <FAStep01LT progressStatus={setProgress} />
                <FAStep02LT progressStatus={setProgress} />
                <FAStep03LT progressStatus={setProgress} />
                <FAStep04LT progressStatus={setProgress} />
                <FAStep05LT progressStatus={setProgress} />
                <FAStep06LT progressStatus={setProgress} />
                <FAStep07LT progressStatus={setProgress} />
                <FAStep08LT progressStatus={setProgress} />
                <FAStep09LT progressStatus={setProgress} />
                <FAStep10LT progressStatus={setProgress} />
                <FAStep11LT progressStatus={setProgress} />
                <FAStep12LT progressStatus={setProgress} />
                {/* <FAStep13LT progressStatus={setProgress} />
                <FAStep14LT progressStatus={setProgress} />
                <FAStep15LT progressStatus={setProgress} />
                <FAStep16LT progressStatus={setProgress} /> */}
                {/* FORM B steps */}
                {/* FORM B steps */}
                {/* FORM B steps */}
                <FBStep01LT progressStatus={setProgress} />
                <FBStep02LT progressStatus={setProgress} />
                <FBStep03LT progressStatus={setProgress} />
                <FBStep04LT progressStatus={setProgress} />
                <FBStep05LT progressStatus={setProgress} />
                <FBStep06LT progressStatus={setProgress} />
                <FBStep07LT progressStatus={setProgress} />
                <FBStep08LT progressStatus={setProgress} />
                <FBStep09LT progressStatus={setProgress} />
                <FBStep10LT progressStatus={setProgress} />
                <FBStep11LT progressStatus={setProgress} />
                <FBStep12LT progressStatus={setProgress} />
                {/* <FBStep13LT progressStatus={setProgress} />
                <FBStep14LT progressStatus={setProgress} /> */}
                {/* FORM C steps */}
                {/* FORM C steps */}
                {/* FORM C steps */}
                <FCStep01LT progressStatus={setProgress} />
                <FCStep02LT progressStatus={setProgress} />
                <FCStep03LT progressStatus={setProgress} />
                <FCStep04LT progressStatus={setProgress} />
                <FCStep05LT progressStatus={setProgress} />
                <FCStep06LT progressStatus={setProgress} />
                <FCStep07LT progressStatus={setProgress} />
                <FCStep08LT progressStatus={setProgress} />
                <FCStep09LT progressStatus={setProgress} />
                <FCStep10LT progressStatus={setProgress} />
                <FCStep11LT progressStatus={setProgress} />
                {/* FORM D steps */}
                {/* FORM D steps */}
                {/* FORM D steps */}
                <FDStep01LT progressStatus={setProgress} />
                <FDStep02LT progressStatus={setProgress} />
                <FDStep03LT progressStatus={setProgress} />
                <FDStep04LT progressStatus={setProgress} />
                <FDStep05LT progressStatus={setProgress} />
                <FDStep06LT progressStatus={setProgress} />
                <FDStep07LT progressStatus={setProgress} />
                <FDStep08LT progressStatus={setProgress} />
                {/* <FDStep09LT progressStatus={setProgress} /> */}
                {/* FORM E steps */}
                {/* FORM E steps */}
                {/* FORM E steps */}
                <FEStep01LT progressStatus={setProgress} />
                <FEStep02LT progressStatus={setProgress} />
                <FEStep03LT progressStatus={setProgress} />
                <FEStep04LT progressStatus={setProgress} />
                <FEStep05LT progressStatus={setProgress} />
                <FEStep06LT progressStatus={setProgress} />
                {/* FORM F steps */}
                {/* FORM F steps */}
                {/* FORM F steps */}
                <FFStep01LT progressStatus={setProgress} />
                <FFStep02LT progressStatus={setProgress} />
                <FFStep03LT progressStatus={setProgress} />
                <FFStep04LT progressStatus={setProgress} />
                <FFStep05LT progressStatus={setProgress} />
                {/* FORM G steps */}
                {/* FORM G steps */}
                {/* FORM G steps */}
                <FGStep01LT progressStatus={setProgress} />
                <FGStep02LT progressStatus={setProgress} />
                <FGStep03LT progressStatus={setProgress} />
                {/* FORM H steps */}
                {/* FORM H steps */}
                {/* FORM H steps */}
                <FHStep01LT progressStatus={setProgress} />
                <FHStep02LT progressStatus={setProgress} />
                <FHStep03LT progressStatus={setProgress} />
                <FHStep04LT progressStatus={setProgress} />
                {/* FORM I steps */}
                {/* FORM I steps */}
                {/* FORM I steps */}
                <FIStep01LT progressStatus={setProgress} />
                <FIStep02LT progressStatus={setProgress} />
                <FIStep03LT progressStatus={setProgress} />
                {/* FORM J steps */}
                {/* FORM J steps */}
                {/* FORM J steps */}
                <FJStep01LT progressStatus={setProgress} />
                <FJStep02LT progressStatus={setProgress} />
                <FJStep03LT progressStatus={setProgress} />
                <FJStep04LT progressStatus={setProgress} />
              </StepWizard>
              <StoreSettings />
            </div>
          </div>
        </div>
        <FooterV2 lightTheme />
      </section>
    </>
  );
};

export default FormFiveLightTheme;
