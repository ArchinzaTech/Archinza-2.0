import React, { useEffect, useRef, useState } from "react";
import "./businessprofile.scss";
import FooterV2 from "../../components/FooterV2/FooterV2";
import BusinessBanner from "../../components/BusinessProfileBanner/BusinessBanner";
import {
  rightarrowblack,
  greentick,
  leftarrowBlack,
  brightarrowBlack,
} from "../../images";
import AboutFirm from "./AboutFirm/AboutFirm";
import AboutProject from "./AboutProject/AboutProject";
import SupportingDocuments from "./SupportingDocuments/SupportingDocuments";
import { useWindowSize } from "react-use";

const BusinessProfile = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [ctaStatus, setCtaStatus] = useState(0);
  const [boxPositionFromLeft, setBoxPositionFromLeft] = useState(0);
  const contentContainerRef = useRef(null);
  const { width } = useWindowSize();
  const brandNameBoxRef = useRef();

  const containerPositionHandler = () => {
    if (contentContainerRef.current) {
      contentContainerRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };

  const handleCountChange = (increment) => {
    const newValue = (activeTab + increment + 3) % 3;
    setActiveTab(newValue);
  };

  const handleCtaChange = () => {
    const newValue = (ctaStatus + 1 + 2) % 2;
    setCtaStatus(newValue);
  };
  function handleClick() {
    console.log(brandNameBoxRef.current);
  }

  useEffect(() => {
    containerPositionHandler();
  }, [activeTab]);

  useEffect(() => {
    setBoxPositionFromLeft(brandNameBoxRef.current.offsetLeft);
  }, []);

  useEffect(() => {
    window.scroll(0, 0);
  }, []);

  return (
    <>
      <section className="bizp_bg"></section>
      <BusinessBanner
        boxRef={brandNameBoxRef}
        brandName="GORTEX ARCHITECTURE dummy added to check if business name is longer than space"
      />
      <section className="bizp_sec1" ref={contentContainerRef}>
        <div className="my_container">
          <div
            className="cta_wrapper top_ctas"
            style={{ paddingLeft: boxPositionFromLeft }}
          >
            <div className="cta_flex">
              <div className="common_cta without_shadow" onClick={handleClick}>
                <div className="text">
                  {width > 600 ? "Save Changes" : "Save"}
                </div>
              </div>
              <div className="common_cta without_shadow black_border_cta">
                <div className="text">
                  {width > 600 ? "Discard Changes" : "Discard"}
                </div>
              </div>
            </div>
            <div
              className={`common_cta without_shadow ${
                ctaStatus === 0 ? "disabled_cta" : "online_cta black_border_cta"
              }`}
              onClick={handleCtaChange}
            >
              {ctaStatus === 0 && (
                <img
                  src={greentick}
                  alt="icon"
                  className="tick_icon"
                  loading="lazy"
                />
              )}
              <div className="text">
                {ctaStatus === 0 && "Get Verified Now"}
                {ctaStatus === 1 && "Go Online Now"}
              </div>
              <img
                src={rightarrowblack}
                alt="icon"
                className="icon"
                loading="lazy"
              />
            </div>
          </div>
          <div className="row g-0">
            <div className="col-lg-6 p-0">
              <div className="business_details_wrapper">
                <AboutFirm />
              </div>
            </div>
            <div className="col-lg-6 p-0">
              <div className="business_details_wrapper">
                <AboutProject />
                {/* <SupportingDocuments /> */}
              </div>
            </div>
          </div>
        </div>
      </section>
      <FooterV2 lightTheme />
    </>
  );
};

export default BusinessProfile;
