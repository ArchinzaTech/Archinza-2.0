import React, { useEffect, useState } from "react";
import { editiconorange } from "../../../images";
import AutoCompleteField from "../../../components/AutoCompleteField/AutoCompleteField";
// import { countries } from "../../../db/dataTypesData";
import { useWindowSize } from "react-use";
import FullWidthTextField from "../../../components/TextField/FullWidthTextField";
import TextFieldWithIcon from "../../../components/TextFieldWithIcon/TextFieldWithIcon";
import { useAuth } from "../../../context/Auth/AuthState";
import config from "../../../config/config";
import Joi from "joi";
import http from "../../../helpers/http";
import { toast } from "react-toastify";
import ToastMsg from "../../../components/ToastMsg/ToastMsg";
const EditCountry = () => {
  // =============== VARIABLE & STATES  ===========================

  const { width } = useWindowSize();

  const [isEditClicked, setIsEditClicked] = useState(false);
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);
  const [values, setValues] = useState({
    country: "",
    city: "",
    pincode: "",
  });
  const [formError, setFormError] = useState({});

  const auth = useAuth();

  const joiOptions = config.joiOptions;

  const base_url = config.api_url; //without trailing slash

  // =============== FUNCTIONS  ===========================

  const handleChange = (e) => {
    setValues((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
      };
    });
  };

  const handleSelectChange = (value, fieldName) => {
    setValues((prevState) => {
      return {
        ...prevState,
        [fieldName]: value,
      };
    });
  };

  const validate = async (data) => {
    let schemaObj = {
      country: Joi.string().trim().required().label("Country"),
    };

    if (data.country == "India") {
      schemaObj.city = Joi.string().trim().required().label("City");

      schemaObj.pincode = Joi.number().required().label("Pincode");
    }

    const schema = Joi.object(schemaObj).options({ allowUnknown: true });

    const { error } = schema.validate(data, joiOptions);

    const errors = {};

    if (error) {
      error.details.map((field) => {
        errors[field.path[0]] = field.message;
        return true;
      });
    }

    return errors ? errors : null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    let errors = await validate(values);

    setFormError(errors);
    if (Object.keys(errors).length) {
      return;
    }

    let formValues = values;

    if (formValues.country != "India") {
      formValues.city = "";
      formValues.pincode = "";
    }

    const data = await http.put(
      base_url + "/personal/edit-profile/" + auth?.user?._id,
      formValues
    );

    if (data) {
      auth.refresh();
      toast(
        <ToastMsg message="Your detail is updated" />,
        config.success_toast_config
      );
      setValues({});
      setIsEditClicked(false);
    }
  };

  // =============== HTML RENDERING  ===========================
  // =============== DATA FETCHING  ===========================

  const fetchCountires = async () => {
    const { data } = await http.get(base_url + "/general/countries");

    if (data) {
      setCountries(data);
    }
  };
  const fetchCities = async () => {
    const country_id = 101;
    const { data } = await http.get(
      base_url + "/general/cities-by-country/" + country_id
    );

    if (data) {
      setCities(data);
    }
  };
  // =============== SIDE EFFECTS  ===========================

  useEffect(() => {
    fetchCountires();
    fetchCities();
  }, []);

  return (
    <>
      {!isEditClicked && (
        <>
          <div className={`col-lg-6 ${width > 992 && "ps-0"}`}>
            <div
              className="field_wrapper padding_right"
              onClick={() => setIsEditClicked(true)}
            >
              <TextFieldWithIcon
                label="Country*"
                value={auth?.user?.country || ""}
                icon={editiconorange}
              />
            </div>
          </div>
          {auth?.user?.country === "India" && (
            <>
              <div className={`col-lg-6 ${width > 992 && "pe-0"}`}>
                <div
                  className="field_wrapper padding_left"
                  // onClick={() => setIsEditClicked(true)}
                >
                  <TextFieldWithIcon
                    label="City*"
                    value={auth?.user?.city || ""}
                    // icon={editiconorange}
                  />
                  {/* <p className="error"></p> */}
                </div>
              </div>

              <div className={`col-lg-6 ${width > 992 && "ps-0"}`}>
                <div
                  className="field_wrapper padding_right"
                  // onClick={() => setIsEditClicked(true)}
                >
                  <TextFieldWithIcon
                    label="Pincode*"
                    value={auth?.user?.pincode || ""}
                    // icon={editiconorange}
                  />
                  {/* <p className="error"></p> */}
                </div>
              </div>
            </>
          )}
        </>
      )}

      {isEditClicked && (
        <>
          <form onSubmit={handleSubmit} className="country_form">
            <div className={`col-lg-6 ${width > 992 && "ps-0"}`}>
              <div className="field_wrapper padding_right">
                <AutoCompleteField
                  key="country"
                  textLabel="Country*"
                  data={countries}
                  onChange={(e, option) => {
                    handleSelectChange(option.value, "country");
                  }}
                />
                {formError.country && (
                  <p className="error">{formError.country}</p>
                )}
              </div>
            </div>
            {values?.country === "India" && (
              <>
                {" "}
                <div className={`col-lg-6 ${width > 992 && "pe-0"}`}>
                  <div className="field_wrapper padding_left">
                    <AutoCompleteField
                      key="city"
                      textLabel="City*"
                      data={cities}
                      onChange={(e, option) => {
                        handleSelectChange(option.value, "city");
                      }}
                    />
                    {formError.city && (
                      <p className="error">{formError.city}</p>
                    )}
                  </div>
                </div>
                <div className={`col-lg-6 ${width > 992 && "ps-0"}`}>
                  <div className="field_wrapper padding_right">
                    <FullWidthTextField
                      type="tel"
                      label="Pincode*"
                      name="pincode"
                      value={values.pincode}
                      onChange={handleChange}
                    />
                    {formError.pincode && (
                      <p className="error">{formError.pincode}</p>
                    )}
                  </div>
                </div>
              </>
            )}

            <div className={`col-lg-6 ${width > 992 && "pe-0"}`}>
              <div className="mobile_center location_cta">
                <div className="btn_wrapper">
                  <button className="submit_button">Submit</button>
                  <button
                    type="button"
                    className="back_button"
                    onClick={() => setIsEditClicked(false)}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </form>
        </>
      )}
    </>
  );
};

export default EditCountry;
