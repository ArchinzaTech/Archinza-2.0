import React, { useEffect } from "react";
import "./congratulationsLT.scss";
import { congratCupWhite, rightarrowblack } from "../../images";
import { useWindowSize } from "react-use";
import FooterV2 from "../../components/FooterV2/FooterV2";
import ReactConfetti from "react-confetti";

const CongratulationsLT = () => {
  const { width, height } = useWindowSize();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <main className="congrat_lt__main">
        <div className="confetti_wrapper">
          <ReactConfetti
            width={width - 50}
            height={height}
            colors={["#a67c00", "#bf9b30", "#ffbf00"]}
          />
        </div>

        <section className="congrat_lt_sec1">
          <div className="my_container">
            <div className="content_wrapper">
              <img src={congratCupWhite} alt="cup" className="cup" loading="lazy" />
              <h2 className="title">Congratulations!</h2>
              <p className="sub_title">on completing your registration.</p>
              <p className="desc">
                Get Ready To Unlock A World Of Opportunities For Your Business
                With {""}
                <span className="col_black">Archinza</span>!
              </p>
              <div className="cta_wrapper">
                <div className="next_button">
                  <div className="text">Edit Your Business Page</div>
                  <img
                    src={rightarrowblack}
                    alt="icon"
                    className="icon"
                    loading="lazy"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        <FooterV2 />
      </main>
    </>
  );
};

export default CongratulationsLT;
