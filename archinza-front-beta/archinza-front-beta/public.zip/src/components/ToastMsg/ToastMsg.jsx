import React from "react";
import { checkiconWhite, errorFailed } from "../../images";
export default function ToastMsg({ message }) {
  return (
    <div className="otp_box">
      <img
        width={39}
        height={39}
        src={message === "Invalid OTP" ? errorFailed : checkiconWhite}
        className="otp_resend_icon"
        alt="icon"
      />
      <p className="title">{message}</p>
    </div>
  );
}
