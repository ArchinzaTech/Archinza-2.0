import style from "./autocompleteothers.module.scss";
import TextField from "@mui/material/TextField";
import Autocomplete, { createFilterOptions } from "@mui/material/Autocomplete";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import { useWindowSize } from "react-use";
import { dropdownarrow } from "../../images";
import { VirtualizedListBox } from "../VirtualizedListBox/VirtualizedListBox";

const darkTheme = createTheme({
  typography: {
    fontFamily: "Poppins",
  },
  palette: {
    mode: "dark",
  },
});
const lightThemed = createTheme({
  typography: {
    fontFamily: "Poppins",
  },
  palette: {
    mode: "light",
  },
});

const filter = createFilterOptions();

const AutoCompleteOthers = ({ textLabel, data, lightTheme, ...rest }) => {
  const { width } = useWindowSize();

  return (
    <>
      <ThemeProvider theme={lightTheme ? lightThemed : darkTheme}>
        <CssBaseline />
        <Autocomplete
          // value={value}
          // onChange={(event, newValue) => {
          //   if (typeof newValue === "string") {
          //     setValue({
          //       label: newValue,
          //     });
          //   } else if (newValue && newValue.inputValue) {
          //     // Create a new value from the user input
          //     setValue({
          //       label: newValue.inputValue,
          //     });
          //   } else {
          //     setValue(newValue);
          //   }
          // }}

          getOptionDisabled={(option) => option.disabled === true}
          filterOptions={(options, params) => {
            const filtered = filter(options, params);

            const { inputValue } = params;
            // Suggest the creation of a new value
            const isExisting = options.some(
              (option) => inputValue === option.value
            );
            if (inputValue !== "" && !isExisting) {
              filtered.push({
                value: inputValue,
                label: `Add "${inputValue}"`,
              });
            }

            return filtered;
          }}
          selectOnFocus
          clearOnBlur
          handleHomeEndKeys
          freeSolo
          className={
            lightTheme
              ? style.autocomplete_dropdown_light
              : style.autocomplete_dropdown
          }
          options={data}
          autoHighlight
          disableClearable
          getOptionLabel={(option) => option.value}
          sx={{
            "& fieldset": {
              borderRadius: width > 768 ? "10px" : "10px",
              border: "1px solid #707070",
            },
            "& .MuiOutlinedInput-root": {
              borderRadius: width > 768 ? "10px" : "10px",
            },
            "& label": {
              lineHeight: width > 768 ? "2em" : "1.5em",
            },
            "& label.Mui-focused": {
              color: lightTheme ? "#111" : "fff",
            },
            "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
              borderRadius: width > 768 ? "10px" : "10px",
              border: "1px solid #707070",
            },
            "& .MuiOutlinedInput-root .Mui-focused .MuiOutlinedInput-notchedOutline":
              {
                border: "1px solid #707070",
              },
            "&.Mui-focused .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline":
              {
                borderColor: lightTheme ? "#111" : "fff",
              },
            "& .MuiSvgIcon-root ": {
              fill: "#f77b00 !important",
            },
          }}
          // renderOption={(props, option) => (
          //   <Box className={style.option_list} component="li" {...props}>
          //     {option.label}
          //   </Box>
          // )}
          ListboxComponent={VirtualizedListBox}
          renderInput={(params) => (
            <>
              <TextField
                {...params}
                label={textLabel}
                inputProps={{
                  style: {
                    fontSize: width > 768 ? "1.25em" : "1.25em",
                  },
                  ...params.inputProps,
                }}
              />
              <img
                width={10}
                height={8}
                src={dropdownarrow}
                alt="arrow"
                className={style.autocomplete_drop_arrow}
                loading="lazy"
              />
            </>
          )}
          {...rest}
        />
      </ThemeProvider>
    </>
  );
};

export default AutoCompleteOthers;
