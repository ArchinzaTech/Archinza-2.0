import { Navigate } from "react-router-dom";
import { loginURL } from "../helpers/constant-words";
// import { useAuth } from "../../context/AuthContext";
import helper from "../../helpers/helper";
import { useAuth } from "../../context/Auth/AuthState";

export const ProtectedRoute = ({ children, guard=null }) => {

  const auth = useAuth();

  
  if (!auth.isLoggedIn()) {
    // user is not authenticated
    return (
      <Navigate to={loginURL} />
    );
  }
  return children;
};
