import React from "react";
import "./dashboardnotice.scss";

const DashboardNoticeCard = ({ notice }) => {
  return (
    <>
      <div className="notice_card">
        {/* <h2 className="heading">{title}</h2> */}
        <p className="desc">{notice}</p>
      </div>
    </>
  );
};

export default DashboardNoticeCard;
