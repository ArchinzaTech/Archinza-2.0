import React, { useState, useEffect, useRef } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import "./header.scss";
import { useWindowSize } from "react-use";
import {
  blacklogo,
  dropdownarrow,
  facebook,
  fbHeader,
  fbHeaderB,
  insta,
  instaHeader,
  instaHeaderB,
  linkedIn,
  linkedinHeader,
  linkedinHeaderB,
  loginicon,
  logoutIcon,
  prologo,
  prologoblack,
  rightarrowblack,
  rightarrowwhite,
  whitelogo,
} from "../../images";
import {
  accountCategoryURL,
  businessFormFiveLTURL,
  businessProfileURL,
  congratulationsLightURL,
  dashboardURL,
  contactUsURL,
  editProfile,
  facebookURL,
  homepageURL,
  instagramURL,
  linkedinURL,
  loginURL,
  registrationBusinessURL,
  registrationFormURL,
} from "../helpers/constant-words";
import HeaderNavItem from "./HeaderNavItem";
import GlowCta from "../GlowCta/GlowCta";
import config from "../../config/config";

import { useAuth } from "../../context/Auth/AuthState";
import _filter from "lodash/filter";
import http from "../../helpers/http";
// const body = document.querySelector("body");

const Header = () => {
  const [loading, setLoading] = useState(true);
  const [navlinkIndex, setNavlinkIndex] = useState(null);
  const { width } = useWindowSize();
  const { height } = useWindowSize();
  const [navActiveIndex, setNavActiveIndex] = useState(null);
  const [isMenuActive, setIsMenuActive] = useState(false);
  const [isPro, setIsPro] = useState(false);
  const [userState, setUserState] = useState(0);
  const [userCategory, setUserCategory] = useState(1);
  const [dropdownActive, setDropdownActive] = useState(false);
  const [isDashboard, setIsDashboard] = useState(false);
  const [isLightTheme, setIsLightTheme] = useState(false);
  const headerRef = useRef(null);
  const location = useLocation();
  const [isNewAccDropdown, setIsNewAccDropdown] = useState(false);
  const [headerWidth, setHeaderWidth] = useState();

  const auth = useAuth();
  const navigate = useNavigate();
  const base_url = config.api_url;

  const fetchEntry = async (id, user_type) => {
    const { data } = await http.get(
      `${base_url}/pro-access/entries/${user_type}/${id}`
    );

    if (data) {
      if (data?.status === "completed") {
        setIsPro(true);
      } else {
        setIsPro(false);
      }
    }
  };

  useEffect(() => {
    if (auth.user) {
      const id = auth?.user?._id;
      const user_type = auth?.user?.user_type;
      fetchEntry(id, user_type);
    }
  }, [auth]);

  const navLinksArr = [
    {
      id: 1,
      type: "img",
      img: whitelogo,
      mainLink: "/",
      class: "logo_img",
    },
    {
      id: 3,
      type: "text",
      mainTitle: "KNOW",
      mainLink: homepageURL,
    },
    {
      id: 4,
      type: "text",
      mainTitle: "CONNECT",
      mainLink: contactUsURL,
    },
    {
      id: 5,
      type: "text",
      mainTitle: "BLOG",
      mainLink: homepageURL,
    },
    {
      id: 6,
      type: "social",
      links: [
        { img: isLightTheme ? fbHeaderB : fbHeader, url: facebookURL },
        { img: isLightTheme ? instaHeaderB : instaHeader, url: instagramURL },
        {
          img: isLightTheme ? linkedinHeaderB : linkedinHeader,
          url: linkedinURL,
        },
      ],
    },
  ];

  const usersArr = [
    {
      categoryId: 0,
      category: "student",
      background: "#FF4A68",
      users: [
        {
          name: "Habib",
          age: "",
          company: "TOGGLEHEAD",
        },
      ],
    },
    {
      categoryId: 1,
      category: "team-member",
      background: "#12CC50",
      users: [
        {
          name: "Talha",
          age: "",
          company: "TOGGLEHEAD",
        },
      ],
    },
    {
      categoryId: 2,
      category: "design-enthusiast",
      background: "#014FE0",
      users: [
        {
          name: "Ayushi",
          age: "",
          company: "Facebook",
        },
      ],
    },
    {
      categoryId: 3,
      category: "business-firm-owner",
      background: "#CC9921",
      users: [
        {
          name: "Elon",
          age: "",
          company: "Tesla",
        },
      ],
    },
  ];

  const [mobNavLinksArr, setmobNavLinksArr] = useState([
    {
      id: 1,
      type: "text",
      mainTitle: "Dashboard",
      mainLink: dashboardURL,
    },
    {
      id: 2,
      type: "text",
      mainTitle: "KNOW",
      mainLink: homepageURL,
    },
    {
      id: 3,
      type: "text",
      mainTitle: "CONNECT",
      mainLink: contactUsURL,
    },
    {
      id: 4,
      type: "text",
      mainTitle: "BLOG",
      mainLink: homepageURL,
    },
  ]);

  useEffect(() => {
    setHeaderWidth(headerRef.current.clientWidth);
  }, [width, height]);

  const handlelogout = () => {
    auth.logout();

    navigate(loginURL, { replace: true });
  };
  function userStatusHandler(e) {
    if (userCategory !== usersArr.length - 1) {
      setUserCategory(userCategory + 1);
    } else {
      setUserCategory(0);
    }
  }

  const scrollHandler = () => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "smooth",
    });
  };

  const handleHamburgerClick = () => {
    setIsMenuActive(!isMenuActive);
    // if (!isMenuActive) {
    //   // Disable scroll
    //   body.style.overflow = "hidden";
    // } else {
    //   // Enable scroll
    //   body.style.overflow = "auto";
    // }
    setDropdownActive(false);
  };

  const handleNavIndex = (i) => {
    if (navActiveIndex === i) {
      setNavActiveIndex(null);
    } else {
      setNavActiveIndex(i);
    }
  };

  const navlinkList = navLinksArr.map((nav, i) => (
    <li key={navLinksArr[i].id}>
      {nav.type === "img" && (
        <div
          onClick={() => setNavlinkIndex(i)}
          className={`logo_wrapper ${navlinkIndex === i ? "" : ""} `}
        >
          <a href={homepageURL}>
            <img
              width={292}
              className={nav.class}
              src={`${
                isPro
                  ? isLightTheme
                    ? prologoblack
                    : prologo
                  : isLightTheme
                  ? blacklogo
                  : whitelogo
              }`}
              alt="atlas img"
              onClick={scrollHandler}
              loading="eager"
            />
          </a>
        </div>
      )}
      {nav.type === "text" && (
        <div
          onClick={() => setNavlinkIndex(i)}
          className={`nav_tab ${navlinkIndex === i ? "active" : ""} `}
        >
          {nav.linktype === "external" ? (
            <a
              className={nav.class}
              href={nav.mainLink}
              target="_blank"
              rel="noreferrer"
            >
              {nav.mainTitle}
            </a>
          ) : (
            // <Link className={nav.class} to={nav.mainLink}>
            <Link
              className={`${
                nav.linkVariant === "dashboard" && isDashboard === true
                  ? ""
                  : nav.class
              }`}
              to={nav.mainLink}
            >
              {nav.mainTitle}
            </Link>
          )}
        </div>
      )}

      {isDashboard === true
        ? nav.type === "search" && (
            <div className="nav_tab">
              <img src={nav.img} alt="search" className={nav.class} />
            </div>
          )
        : null}

      {nav.type === "social" && (
        <div
          onClick={() => setNavlinkIndex(i)}
          className={`nav_tab social_links ${
            navlinkIndex === i ? "active" : ""
          } `}
        >
          {nav.links.map((item) => (
            <a
              className={nav.class}
              href={item.url}
              target="_blank"
              rel="noreferrer"
              key={item.url}
            >
              <img
                width={30}
                height={30}
                src={item.img}
                alt={item.url}
                className="social_img"
              />
            </a>
          ))}
        </div>
      )}

      {isDashboard === false
        ? nav.type === "form" && (
            <div
              //   onClick={userStateHandler}
              className={`nav_tab bg_cta ${
                navlinkIndex === i ? "active" : ""
              } `}
            >
              <Link
                className="multi_text"
                to={nav.userStates[userState].slug}
                // style={{ pointerEvents: "none" }}
              >
                <div className="title">{nav.userStates[userState].title}</div>
                <div>
                  <img
                    width={28.48}
                    src={isLightTheme ? rightarrowblack : rightarrowwhite}
                    alt="right arrow"
                    className="right_arrow"
                  />
                  {/* <img
                width={15.5}
                src={blackright}
                alt="right arrow"
                className="right_arrow"
              /> */}
                </div>
              </Link>
            </div>
          )
        : null}
    </li>
  ));

  useEffect(() => {
    if (location.pathname === dashboardURL) {
      setIsDashboard(true);
    } else {
      setIsDashboard(false);
    }
  }, [location.pathname]);

  useEffect(() => {
    if (
      location.pathname === businessFormFiveLTURL ||
      location.pathname === businessProfileURL ||
      location.pathname === registrationBusinessURL ||
      location.pathname === congratulationsLightURL
    ) {
      setIsLightTheme(true);
    } else {
      setIsLightTheme(false);
    }
    setLoading(false);
  }, [location.pathname]);

  useEffect(() => {
    setIsMenuActive(false);
  }, [location.pathname]);

  return (
    <>
      {loading && (
        <div className="loadergifdiv">
          <img src={whitelogo} alt="loader" className="img-fluid" />
        </div>
      )}
      <div
        className={`desktop_blank ${
          isLightTheme ? "desktop_blank_light" : "desktop_blank_dark"
        }`}
      ></div>
      <header
        ref={headerRef}
        className={`header_sec ${
          isLightTheme ? "header_light" : "header_dark"
        } ${isMenuActive ? "menuactive" : ""}   `}
      >
        <div
          className="backdrop_header"
          style={{ width: `${headerWidth}px` }}
        ></div>
        {width > 1080 ? (
          <>
            {/* <div className="desktop_blank"></div> */}
            <div className="my_container">
              <div className="navlinks">
                <ul>
                  {auth.isLoggedIn() === true && (
                    <li>
                      <div className="nav_tab">
                        <Link to={dashboardURL}>DASHBOARD</Link>
                      </div>
                    </li>
                  )}

                  {navlinkList}
                  {auth.isLoggedIn() === false && (
                    <li>
                      {(location.pathname === homepageURL ||
                        location.pathname === accountCategoryURL ||
                        location.pathname === loginURL) && (
                        <div className={`nav_tab bg_cta `}>
                          <Link className="multi_text" to={accountCategoryURL}>
                            <div className="title">Get Early Access</div>
                            <div>
                              <img
                                width={28.48}
                                src={
                                  isLightTheme
                                    ? rightarrowblack
                                    : rightarrowwhite
                                }
                                alt="right arrow"
                                className="right_arrow"
                              />
                            </div>
                          </Link>
                        </div>
                      )}
                      {location.pathname === registrationFormURL && (
                        <div className={`nav_tab bg_cta `}>
                          <Link className="multi_text" to={accountCategoryURL}>
                            <div className="title">Create Business Account</div>
                            <div>
                              <img
                                width={28.48}
                                src={
                                  isLightTheme
                                    ? rightarrowblack
                                    : rightarrowwhite
                                }
                                alt="right arrow"
                                className="right_arrow"
                              />
                            </div>
                          </Link>
                        </div>
                      )}
                    </li>
                  )}

                  <li>
                    {auth.isLoggedIn() === true && (
                      <div
                        className="nav_tab user_tab"
                        // onClick={userStatusHandler}
                        onMouseOver={() => setDropdownActive(true)}
                        onMouseOut={() => setDropdownActive(false)}
                      >
                        <Link className="user" to={() => false}>
                          {/* <div className="title">
                            {usersArr[userCategory].users[0].name}
                          </div> */}
                          <div
                            className="initial_circle"
                            style={{
                              background: auth?.user?.userType?.color,
                            }}
                          >
                            <div className="name">{auth?.user?.name}</div>
                          </div>
                          <div className="dropdown_arrow_wrap">
                            <img
                              width={9}
                              src={dropdownarrow}
                              alt="dropdown arrow"
                              className="dropdown_arrow"
                            />
                          </div>
                        </Link>
                      </div>
                    )}
                    {auth.isLoggedIn() === false && (
                      <div className="nav_tab login_tab">
                        <Link className="login" to={loginURL}>
                          <div className="title">LOGIN</div>
                          <div>
                            <img
                              width={30}
                              height={30}
                              src={loginicon}
                              alt="login icon"
                              className="login_icon"
                            />
                          </div>
                        </Link>
                      </div>
                    )}
                    {dropdownActive === true && (
                      <>
                        <div
                          className="dropdown_box"
                          onMouseOver={() => setDropdownActive(true)}
                          onMouseOut={() => setDropdownActive(false)}
                        >
                          <div className="drop_content_box">
                            <div className="dropdown_box_arrow">
                              <img
                                src={dropdownarrow}
                                alt="up arrow"
                                className="up_arrow"
                              />
                            </div>
                            <Link
                              to={editProfile}
                              className="dropdown_list name"
                            >
                              {auth?.user?.name}
                            </Link>
                            {/* <div className="dropdown_list">
                          {usersArr[userCategory].users[0].company}
                        </div> */}
                            <div className="dropdown_list">
                              <div
                                className="account_login add_acc"
                                onClick={() =>
                                  setIsNewAccDropdown(!isNewAccDropdown)
                                }
                              >
                                ADD ACCOUNT
                                <img
                                  className="dropdown_arrow"
                                  src={dropdownarrow}
                                  alt="down arrow"
                                />
                              </div>
                              {isNewAccDropdown && (
                                <div className="login_wrapper">
                                  <Link to={loginURL} className="login_link">
                                    LOG INTO EXISTING ACCOUNT
                                  </Link>
                                  <br />
                                  <Link
                                    to={accountCategoryURL}
                                    className="login_link"
                                  >
                                    CREATE NEW ACCOUNT
                                  </Link>
                                </div>
                              )}
                            </div>
                            <div
                              className="dropdown_list account_login"
                              onClick={handlelogout}
                            >
                              LOG OUT
                              <img
                                className="logout_icon"
                                src={logoutIcon}
                                // src={download_icon}
                                alt="down arrow"
                              />
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </li>
                </ul>
              </div>
            </div>
          </>
        ) : (
          <>
            <header className="header">
              <div className="my_container">
                <div className="login_container">
                  <div className="logo_wrapper">
                    <Link className="logo_link" to="/">
                      <img
                        src={`${
                          isPro
                            ? isLightTheme
                              ? prologoblack
                              : prologo
                            : isLightTheme
                            ? blacklogo
                            : whitelogo
                        }`}
                        alt="atlas logo"
                        className="atlas_logo"
                        onClick={() => setIsPro(true)}
                      />
                    </Link>
                  </div>
                  <div>
                    {auth.isLoggedIn() === true && (
                      <div
                        className="nav_tab user_tab"
                        // onClick={userStatusHandler}
                        onMouseOver={() => setDropdownActive(true)}
                      >
                        <Link
                          className="user"
                          to={() => false}
                          onClick={userStatusHandler}
                        >
                          <div
                            className="initial_circle"
                            style={{
                              background: auth?.user?.userType?.color,
                            }}
                          >
                            <div className="name">
                              {auth?.user?.name?.charAt(0)}
                            </div>
                          </div>
                          {/* <div className="dropdown_arrow_wrap">
                            <img
                              width={9}
                              src={dropdownarrow}
                              alt="dropdown arrow"
                              className="dropdown_arrow"
                            />
                          </div> */}
                        </Link>
                        {dropdownActive === true && (
                          <>
                            <div
                              className="dropdown_wrapper"
                              onClick={() => setDropdownActive(false)}
                            ></div>
                            <div
                              className="dropdown_box"
                              onMouseOver={() => setDropdownActive(true)}
                              onMouseOut={() => setDropdownActive(false)}
                            >
                              <div className="drop_content_box">
                                <div className="dropdown_box_arrow">
                                  <img
                                    src={dropdownarrow}
                                    alt="up arrow"
                                    className="up_arrow"
                                  />
                                </div>
                                <div className="dropdown_list name">
                                  {auth?.user?.name}
                                </div>
                                {/* <div className="dropdown_list">
                              {usersArr[userCategory].users[0].company}
                            </div> */}
                                <div className="dropdown_list">
                                  <div
                                    className="account_login add_acc"
                                    onClick={() =>
                                      setIsNewAccDropdown(!isNewAccDropdown)
                                    }
                                  >
                                    ADD ACCOUNT
                                    <img
                                      className="dropdown_arrow"
                                      src={dropdownarrow}
                                      alt="down arrow"
                                    />
                                  </div>
                                  {isNewAccDropdown && (
                                    <div className="login_wrapper">
                                      <Link
                                        to={loginURL}
                                        className="login_link"
                                      >
                                        LOG INTO EXISTING ACCOUNT
                                      </Link>
                                      <br />
                                      <Link
                                        to={accountCategoryURL}
                                        className="login_link"
                                      >
                                        CREATE NEW ACCOUNT
                                      </Link>
                                    </div>
                                  )}
                                </div>
                                <div
                                  className="dropdown_list account_login"
                                  onClick={handlelogout}
                                >
                                  LOG OUT
                                  <img
                                    className="logout_icon"
                                    src={logoutIcon}
                                    // src={download_icon}
                                    alt="down arrow"
                                  />
                                </div>
                              </div>
                            </div>
                          </>
                        )}
                      </div>
                    )}
                    {auth.isLoggedIn() === false && (
                      <div
                        className="nav_tab login_tab"
                        // onClick={() => setLoggedIn(true)}
                      >
                        <Link className="login" to={loginURL}>
                          {/* <div className="title">LOGIN</div> */}
                          <div>
                            <img
                              width={30}
                              height={30}
                              src={loginicon}
                              alt="login icon"
                              className="login_icon"
                            />
                          </div>
                        </Link>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <nav className="nav_links_wrapper">
                <div
                  className={`nav_line2_wrapper_flex_wrapper ${
                    isMenuActive ? "active" : ""
                  }`}
                >
                  <div className="blank"></div>
                  <div className="logo_wrapper">
                    <Link className="logo_link" to="/">
                      <img
                        src={`${isPro ? prologo : whitelogo}`}
                        alt="atlas logo"
                        className="atlas_logo"
                      />
                    </Link>
                  </div>
                  <ul className="nav_line2_wrapper_flex">
                    {mobNavLinksArr.map((navData, i) => (
                      <HeaderNavItem
                        navData={navData}
                        key={parseInt(navData.id)}
                        arrIndex={i}
                        handleNavIndex={handleNavIndex}
                        navActiveIndex={navActiveIndex}
                      />
                    ))}

                    {auth.isLoggedIn() === false && (
                      <>
                        {(location.pathname === homepageURL ||
                          location.pathname === accountCategoryURL ||
                          location.pathname === loginURL) && (
                          <div className="cta_wrapper">
                            <GlowCta
                              link={accountCategoryURL}
                              text="Get Early Access"
                            />
                          </div>
                        )}
                        {location.pathname === registrationFormURL && (
                          <div className="cta_wrapper">
                            <GlowCta
                              link={accountCategoryURL}
                              text="Create Business Account"
                            />
                          </div>
                        )}
                      </>
                    )}

                    <li>
                      {width <= 1023 && (
                        <div className="nav_social_media_icons">
                          <p className="social_title">FOLLOW US ON :</p>
                          <a
                            href="https://www.facebook.com/profile.php?id=100091559990889&mibextid=LQQJ4d"
                            target="_blank"
                            rel="noreferrer"
                          >
                            <img
                              src={facebook}
                              alt="facebook"
                              className="nav_social_icons"
                            />
                          </a>
                          <a
                            href="https://instagram.com/archin.za?igshid=MzRlODBiNWFlZA"
                            target="_blank"
                            rel="noreferrer"
                          >
                            <img
                              src={insta}
                              alt="instagram"
                              className="nav_social_icons"
                            />
                          </a>
                          <a
                            href="https://www.linkedin.com/company/92807055/admin/feed/posts/"
                            target="_blank"
                            rel="noreferrer"
                          >
                            <img
                              src={linkedIn}
                              alt="linkedIn"
                              className="nav_social_icons"
                            />
                          </a>
                        </div>
                      )}
                    </li>
                    {/* <li>
                      {width <= 1023 && (
                        <div className="nav_social_media_icons">
                          <a
                            href={() => false}
                            target="_blank"
                            rel="noreferrer"
                          >
                            <Fbgrey className="nav_social_icons" />
                          </a>
                          <a
                            href={() => false}
                            target="_blank"
                            rel="noreferrer"
                          >
                            <Instagrey className="nav_social_icons" />
                          </a>
                          <a
                            href={() => false}
                            target="_blank"
                            rel="noreferrer"
                          >
                            <Linkgrey className="nav_social_icons" />
                          </a>
                        </div>
                      )}
                    </li> */}
                  </ul>
                </div>
              </nav>

              {/* mobile UI start */}
              <div
                className={`hamburger_lines ${isMenuActive ? "active" : ""}`}
                onClick={handleHamburgerClick}
              >
                <div className="line line1"></div>
                <div className="line line2"></div>
                <div className="line line3"></div>
              </div>
            </header>
          </>
        )}
      </header>
    </>
  );
};

export default Header;
