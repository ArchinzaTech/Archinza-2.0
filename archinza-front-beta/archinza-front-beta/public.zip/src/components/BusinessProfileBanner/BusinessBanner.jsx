import React, { useEffect, useRef, useState } from "react";
import "./businessbanner.scss";
import { editiconwhite, images, logoedit } from "../../images";
import { useWindowSize } from "react-use";
import FullWidthTextField from "../TextField/FullWidthTextField";

const BusinessBanner = ({ brandName, boxRef }) => {
  const { width } = useWindowSize();
  const [profileStatus, setProfileStatus] = useState(0);
  const [newName, setNewName] = useState(false);

  const handleStatusChange = () => {
    const newValue = (profileStatus + 1 + 3) % 3;
    setProfileStatus(newValue);
  };

  return (
    <>
      <section className="business_banner">
        <img
          width={1920}
          height={400}
          src={images.businessprifilebg.image}
          alt="business profile card"
          className="biz_bg_img"
        />
        <div className="blue_strip">
          <div className="my_container">
            <div className="strip_flex">
              <div className="logo_wrapper">
                <div className="logo_box">
                  <img
                    width={300}
                    height={300}
                    src={images.brandlogo.image}
                    alt={images.brandlogo.alt}
                    className="brand_logo"
                  />
                  <img
                    width={60}
                    height={60}
                    src={logoedit}
                    alt="logo edit"
                    className="brand_logo_edit"
                  />
                </div>
              </div>
              <div ref={boxRef} className="edit_brand_wrapper">
                <div className="current_name_wrapper">
                  <h1 title={brandName.toUpperCase()} className="brand_name">
                    {brandName}
                  </h1>
                  {!newName && (
                    <img
                      src={editiconwhite}
                      alt=""
                      className="edit_pin"
                      onClick={() => setNewName(true)}
                    />
                  )}
                </div>
                {newName && (
                  <div className="field_wrapper">
                    <FullWidthTextField lightTheme label="Enter business name*" />
                  </div>
                )}
              </div>
              <div className="profile_status">
                <p
                  className={`status_box ${profileStatus === 0 && "draft"} ${
                    profileStatus === 1 && "completed"
                  } ${profileStatus === 2 && "verified"}`}
                  onClick={handleStatusChange}
                >
                  {profileStatus === 0 && "draft"}
                  {profileStatus === 1 && "completed"}
                  {profileStatus === 2 && "verified"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default BusinessBanner;
