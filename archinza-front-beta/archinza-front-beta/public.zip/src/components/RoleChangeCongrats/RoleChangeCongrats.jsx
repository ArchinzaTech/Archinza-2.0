import React, { useEffect, useRef, useState } from "react";
import "./rolechangecongrats.scss";
import Modal from "react-bootstrap/Modal";
import { changeRoleCup } from "../../images";
import ReactConfetti from "react-confetti";
import { useWindowSize } from "react-use";
import config from "../../config/config";
import _find from "lodash/find";

const RoleChangeCongrats = ({ features, roleColor, updatedRole, ...rest }) => {
  const { windowHeight } = useWindowSize();
  const refContainer = useRef();
  const [dimensions, setDimensions] = useState({
    width: 0,
    height: 0,
  });

  useEffect(() => {
    const updateDimensions = () => {
      if (refContainer.current) {
        setDimensions({
          width: refContainer.current.offsetWidth,
          //   height: refContainer.current.offsetHeight,
        });
      }
    };

    updateDimensions();

    // Add event listener for window resize
    window.addEventListener("resize", updateDimensions);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener("resize", updateDimensions);
    };
  }, []);

  return (
    <>
      <div className="change_role_popup_wrapper">
        <Modal {...rest} className="change_role_popup">
          <Modal.Header closeButton></Modal.Header>
          <Modal.Body ref={refContainer}>
            <div className="confetti_wrapper">
              <ReactConfetti
                width={dimensions.width}
                height={windowHeight}
                colors={["#a67c0066", "#bf9b3066", "#ffbf0066"]}
              />
            </div>
            <div className="content_wrapper">
              <img src={changeRoleCup} alt="cup" className="cup_img" />
              <h2 className="role">
                Congratulations! <br /> You've Switched To <br />
                <span style={{ color: roleColor }}>
                  {_find(config.user_types, { code: updatedRole })?.name}
                </span>
                .
              </h2>
              <p className="access" key={Math.random()}>
                You now have access to these features!
              </p>
              <ul className="feature">
                {features?.map((list) => (
                  <li key={`feature-list-${Math.random()}`}>{list}</li>
                ))}
              </ul>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    </>
  );
};

export default RoleChangeCongrats;
