import style from "./checkboxbutton.module.scss";

const CheckboxButton = ({
  className,
  label,
  labelId,
  isChecked,
  lightTheme,
  ...rest
}) => {
  const classNames = [className];
  return (
    <>
      <div
        className={`${classNames.map((item) => {
          return style[item] + " ";
        })} ${style.checkbox_wrapper} ${
          lightTheme
            ? style.checkbox_wrapper_light
            : style.checkbox_wrapper_dark
        }`}
      >
        <input
          className={style.checkbox_input}
          type="checkbox"
          value={label}
          name="checkbox"
          id={labelId}
          checked={isChecked}
          {...rest}
        />
        <label className={style.checkbox_label} htmlFor={labelId}>
          {label}
          <div className={style.close}></div>
        </label>
      </div>
    </>
  );
};

export default CheckboxButton;
