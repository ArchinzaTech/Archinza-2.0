import React from "react";
import CheckboxButton from "../../CheckboxButton/CheckboxButton";
import SelectDropdown from "../../SelectDropdown/SelectDropdown";
import AutoCompleteOthers from "../../AutoCompleteOthers/AutoCompleteOthers";

const BEPCheckboxesWithOthers = ({
  editDisable = true,
  allOptionData,
  selectedData,
}) => {
  const selectedList = selectedData.map((option) => (
    <CheckboxButton
      className="business_edit_checkbox"
      lightTheme
      label={option}
      labelId={option}
      isChecked={editDisable && true}
    />
  ));

  return (
    <>
      {!editDisable ? (
        <>
          <ul className="checkboxes" style={{ pointerEvents: "none" }}>
            {selectedList}
          </ul>
        </>
      ) : (
        <>
          <div className="autocomplete_others_wrap">
            <AutoCompleteOthers
              lightTheme
              textLabel="Select Services*"
              data={allOptionData}
            />
          </div>
          <ul className="checkboxes">{selectedList}</ul>
        </>
      )}
    </>
  );
};

export default BEPCheckboxesWithOthers;
