import { protag } from "../../images";
import style from "./radiobutton.module.scss";

const RadioButton = ({
  lightTheme,
  label,
  labelId,
  isPro,
  extraSpace = false,
  labelClass = "",
  ...rest
}) => {
  return (
    <>
      <li
        className={`${style.radio_wrapper} ${
          lightTheme ? style.radio_wrapper_light : style.radio_wrapper_dark
        }`}
      >
        {isPro === true && (
          <img
            width={41}
            height={21}
            src={protag}
            alt="pro"
            className={style.protag_img}
            loading="lazy"
          />
        )}
        <input
          className={style.radio_input}
          type="radio"
          id={labelId}
          {...rest}
        />
        <label
          className={`${labelClass} ${style.radio_label} ${
            extraSpace === true && style.extraSpace
          }`}
          htmlFor={labelId}
        >
          {label}
        </label>
      </li>
    </>
  );
};

export default RadioButton;
