// routes name
export const homepageURL = "/";
export const datatypesURL = "/data-types";
export const datatypesLightThemeURL = "/data-types-light-theme";
export const comingsoonURL = "/coming-soon";
export const privacypolicyURL = "/privacy-policy";
export const termsandconditionURL = "/terms-and-conditions";
export const contactUsURL = "/contact-us";
export const faqsURL = "/faqs";
export const BlogsListingURL = "/blogs";
export const BlogsInnerURL = "/blog-inner";

// Login flow
export const loginURL = "/login";
export const loginOtpURL = "/login/otp";
export const resetPassURL = "/reset-password";

// Early access form path
export const registrationFormURL = "/register/personal/basic-details";
export const accountCategoryURL = "/register";
export const regiserOTPURL = "/register/personal/otp";
export const congratulationsURL = "/register/personal/congrats";
export const congratulationsLightURL = "/register/personal/congrats-light";

// Business form flow
export const registrationBusinessURL = "/register/business/basic-details";
export const registrationBusinessOTPURL = "/register/business/otp";
export const businessFormFiveLTURL = "/business/business-details";
export const businessProfileURL = "/business/edit-profile";

// Dashboard paths
export const dashboardURL = "/dashboard";
export const changeRoleURL = "/change-role";

// Profile paths
export const editProfile = "/edit-profile";

// Early access forms
export const proAccessURL = "/pro-access";
export const teamAccesssURL = "/team-member-access";
export const businessAccessURL = "/business-access";
export const businessFormFiveURL = "/business-form";

// Social links
export const facebookURL =
  "https://www.facebook.com/profile.php?id=100091559990889";
export const instagramURL = "https://www.instagram.com/archin.za/";
export const linkedinURL = "https://www.linkedin.com/company/archinza/";
