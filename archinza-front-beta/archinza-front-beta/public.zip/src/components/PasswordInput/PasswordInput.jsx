import React, { useState } from "react";
import IconButton from "@mui/material/IconButton";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import InputAdornment from "@mui/material/InputAdornment";
import FormControl from "@mui/material/FormControl";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import { useWindowSize } from "react-use";

const PasswordInput = ({ hideIcon }) => {
  const [showPassword, setShowPassword] = useState(false);
  const { width } = useWindowSize();

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const darkTheme = createTheme({
    typography: {
      fontFamily: "Poppins",
    },
    palette: {
      mode: "dark",
    },
  });

  return (
    <>
      <ThemeProvider theme={darkTheme}>
        <CssBaseline />
        {hideIcon ? (
          <FormControl fullWidth variant="outlined">
            <InputLabel
              htmlFor="outlined-adornment-password"
              sx={{
                "& label": {
                  lineHeight: width > 768 ? "2em" : "1.5em",
                },
              }}
            >
              Password
            </InputLabel>
            <OutlinedInput
              id="outlined-adornment-password"
              type={showPassword ? "text" : "password"}
              label="Set Password*"
              inputProps={{
                style: {
                  fontSize: width > 768 ? "1.25em" : "1.25em",
                  borderRadius: width > 768 ? "10px" : "10px",
                },
              }}
              sx={{
                "& fieldset": {
                  borderRadius: width > 768 ? "10px" : "10px",
                  border: "1px solid $color-707070",
                  background: "rgba(228, 219, 233, 0.05)",
                },
                // input label when focused
                "& label": {
                  lineHeight: width > 768 ? "2em" : "1.5em",
                },
                // input label when focused
                "& label.Mui-focused": {
                  color: "#fff",
                },
                // focused color for input with variant='standard'
                "& .MuiInput-underline:after": {
                  borderBottomColor: "#fff",
                },
                // focused color for input with variant='filled'
                "& .MuiFilledInput-underline:after": {
                  borderBottomColor: "#fff",
                },
                // focused color for input with variant='outlined'
                "& .MuiOutlinedInput-root": {
                  "&.Mui-focused fieldset": {
                    borderColor: "#fff",
                  },
                },
              }}
            />
          </FormControl>
        ) : (
          <FormControl fullWidth variant="outlined">
            <InputLabel
              htmlFor="outlined-adornment-password"
              sx={{
                "& label": {
                  lineHeight: width > 768 ? "2em" : "1.5em",
                },
              }}
            >
              Password
            </InputLabel>
            <OutlinedInput
              id="outlined-adornment-password"
              type={showPassword ? "text" : "password"}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowPassword}
                    onMouseDown={handleMouseDownPassword}
                    edge="end"
                  >
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              }
              label="Set Password*"
              inputProps={{
                style: {
                  fontSize: width > 768 ? "1.25em" : "1.25em",
                  borderRadius: width > 768 ? "10px" : "10px",
                },
              }}
              sx={{
                "& fieldset": {
                  borderRadius: width > 768 ? "10px" : "10px",
                  border: "1px solid $color-707070",
                  background: "rgba(228, 219, 233, 0.05)",
                },
                // input label when focused
                "& label": {
                  lineHeight: width > 768 ? "2em" : "1.5em",
                },
                // input label when focused
                "& label.Mui-focused": {
                  color: "#fff",
                },
                // focused color for input with variant='standard'
                "& .MuiInput-underline:after": {
                  borderBottomColor: "#fff",
                },
                // focused color for input with variant='filled'
                "& .MuiFilledInput-underline:after": {
                  borderBottomColor: "#fff",
                },
                // focused color for input with variant='outlined'
                "& .MuiOutlinedInput-root": {
                  "&.Mui-focused fieldset": {
                    borderColor: "#fff",
                  },
                },
              }}
            />
          </FormControl>
        )}
      </ThemeProvider>
    </>
  );
};

export default PasswordInput;
