import React from "react";
import "./floatingicon.scss";
import { floatingIcon, floatingIcon1 } from "../../images";
import { Link } from "react-router-dom";

const FloatingIcon = () => {
  return (
    <>
      <div className="floating_sec1">
        <Link to={() => false}>
          <div className="img_wrapper">
            <img src={floatingIcon} alt="whatsapp" className="floating_icon1" />
            <img
              src={floatingIcon1}
              alt="whatsapp"
              className="floating_icon2"
            />
          </div>
        </Link>
      </div>
    </>
  );
};

export default FloatingIcon;
