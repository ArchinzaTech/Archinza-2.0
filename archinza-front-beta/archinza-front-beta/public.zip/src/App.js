import React, { useEffect } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Routing from "./Routing";
import "./common.scss";

// Import AOS styles
import AOS from "aos";
import "aos/dist/aos.css";

// Import Swiper styles
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/autoplay";
import "swiper/css/effect-fade";
import "swiper/css/pagination";
import "swiper/css/effect-coverflow";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AuthState from "./context/Auth/AuthState";
import ProAccessState from "./context/ProAccess/ProAccessState";
function App() {
  useEffect(() => {
    AOS.init({
      duration: 1500,
      // once: true,
    });
  }, []);
  return (
    <>
    <ToastContainer />
    <BrowserRouter>
      <AuthState>
        <ProAccessState>
          <Routes>
            <Route path="*" element={<Routing />} />
          </Routes>
        </ProAccessState>
      </AuthState>
    </BrowserRouter>
  </>
  );
}

export default App;

// git push origin beta
