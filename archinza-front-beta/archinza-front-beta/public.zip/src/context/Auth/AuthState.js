import React, { useState, useContext, useEffect } from "react";

import AuthContext from "./AuthContext";
import config from "../../config/config";

import { useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
// import { isExpired, decodeToken } from "react-jwt";
import helper from "../../helpers/helper";
import http from "../../helpers/http";
const UserState = (props) => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  const base_url = config.api_url; //without trailing slash

  const update = (data) => {
    setUser(data);
  };
  const refresh = () => {
    getUser();
  };

  const logout = () => {
    localStorage.removeItem(config.jwt_auth_key);

    setUser(null);
  };

  const isLoggedIn = () => {
    const token = localStorage.getItem(config.jwt_auth_key);

    return token ? true : false;
  };

  const login = async (token) => {
    localStorage.setItem(config.jwt_auth_key, token);
    let userData;
    if (token) {
      // const isMyTokenExpired = isExpired(token);

      // if (!isMyTokenExpired) {
      //   userData =  jwtDecode(token);
      // }

      userData = jwtDecode(token);

      const userType = helper.getUserType(userData?.user_type);
      userData.userType = userType;
      setUser(userData);
    }

    return userData;
  };

  const fetchUser = async (id) => {
    const { data } = await http.get(base_url + "/personal/details/" + id);

    if (data) {
      const userType = helper.getUserType(data?.user_type);
      data.userType = userType;
      setUser(data);
    }
  };

  const getUser = () => {
    const token = localStorage.getItem(config.jwt_auth_key);
    let userData;
    if (token) {
      // const isMyTokenExpired = isExpired(token);

      // if (!isMyTokenExpired) {
      //   userData =  jwtDecode(token);
      // }

      userData = jwtDecode(token);

      fetchUser(userData?._id);
    }
  };
  useEffect(() => {
    getUser();
  }, []);

  return (
    <AuthContext.Provider
      value={{ user, update, refresh, login, logout, isLoggedIn }}
    >
      {props.children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};

export default UserState;
