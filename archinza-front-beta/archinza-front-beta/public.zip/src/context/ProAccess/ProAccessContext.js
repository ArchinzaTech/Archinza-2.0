import { createContext } from "react";

const ProAccessContext = createContext();

export default ProAccessContext;
