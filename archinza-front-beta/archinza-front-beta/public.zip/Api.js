export const questions = [
    {
        id:1,
        question:'What is Archinza all about?',
        answer:'Lorem Ipsum is dummy text of the printing and typesetting industry, derived from a Latin passage by Cicero. Learn about its history, usage, variations and sources, and how to generate realistic Lorem Ipsum online'
    },
    {
        id:2,
        question:'Who is Archinza for?',
        answer:'Lorem Ipsum is dummy text of the printing and typesetting industry, derived from a Latin passage by Cicero. Learn about its history, usage, variations and sources, and how to generate realistic Lorem Ipsum online'
    },
    {
        id:3,
        question:'When will Archinza launch?',
        answer:'Lorem Ipsum is dummy text of the printing and typesetting industry, derived from a Latin passage by Cicero. Learn about its history, usage, variations and sources, and how to generate realistic Lorem Ipsum online'
    },
    {
        id:4,
        question:'How will Archinza benefit me?',
        answer:'Lorem Ipsum is dummy text of the printing and typesetting industry, derived from a Latin passage by Cicero. Learn about its history, usage, variations and sources, and how to generate realistic Lorem Ipsum online'
    },
    {
        id:5,
        question:'Where do i sign up?',
        answer:'Lorem Ipsum is dummy text of the printing and typesetting industry, derived from a Latin passage by Cicero. Learn about its history, usage, variations and sources, and how to generate realistic Lorem Ipsum online'
    },
    {
        id:6,
        question:'Is Archinza free?',
        answer:'Lorem Ipsum is dummy text of the printing and typesetting industry, derived from a Latin passage by Cicero. Learn about its history, usage, variations and sources, and how to generate realistic Lorem Ipsum online'
    }

]
